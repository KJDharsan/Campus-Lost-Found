@echo off
setlocal
cd /d "%~dp0"

set "DRIVER=lib\sqlite-jdbc-3.49.1.0.jar"
set "DRIVER_URL=https://repo.maven.apache.org/maven2/org/xerial/sqlite-jdbc/3.49.1.0/sqlite-jdbc-3.49.1.0.jar"

if not exist "%DRIVER%" (
    if not exist "lib" mkdir "lib"
    echo Downloading the SQLite JDBC driver...
    curl.exe --fail --location --silent --show-error "%DRIVER_URL%" --output "%DRIVER%"
    if errorlevel 1 (
        if exist "%DRIVER%" del "%DRIVER%"
        echo Could not download the SQLite JDBC driver.
        echo Check your internet connection and try again.
        pause
        exit /b 1
    )
)

if not exist "build" mkdir "build"
javac -cp "%DRIVER%" -d "build" "Findagain.java"
if errorlevel 1 (
    echo Java compilation failed.
    pause
    exit /b 1
)

java -cp "build;%DRIVER%" Findagain
