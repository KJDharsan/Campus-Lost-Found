import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

public class Findagain {
    private static final Color NAVY = new Color(24, 43, 69);
    private static final Color TEAL = new Color(0, 132, 130);
    private static final Color BACKGROUND = new Color(245, 248, 250);
    private static final Color TEXT = new Color(42, 55, 70);
    private static final Color ERROR_BG = new Color(253, 237, 237);
    private static final Color ERROR_BORDER = new Color(217, 83, 79);
    private static final Color ERROR_TEXT = new Color(169, 68, 66);
    private static final Color SUCCESS_BG = new Color(230, 247, 238);
    private static final Color SUCCESS_TEXT = new Color(30, 126, 70);

    private static final Pattern REGISTRATION_PATTERN = Pattern.compile("^AP\\d{11}$");
    private static final Pattern DOB_PASSWORD_PATTERN = Pattern.compile("^\\d{8}$");

    private static final List<Item> items = new ArrayList<>();
    private static ItemDatabase database;

    private final JFrame frame = new JFrame("SRM AP Lost & Found");
    private final CardLayout rootLayout = new CardLayout();
    private final JPanel rootPanel = new JPanel(rootLayout);
    private final CardLayout cardLayout = new CardLayout();
    private final JPanel content = new JPanel(cardLayout);
    private final DefaultTableModel tableModel = new DefaultTableModel(
            new String[]{"ID", "Status", "Item", "Category", "Campus location",
                "Date / time", "Appearance", "Condition", "Registration ID", "Reporter", "Contact"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JComboBox<Item> itemSelector = new JComboBox<>();
    private final JTextArea matchResults = new JTextArea();
    private final JLabel lostCount = new JLabel("0");
    private final JLabel foundCount = new JLabel("0");

    // Login UI state
    private JTextField loginRegField;
    private JPasswordField loginPasswordField;
    private JCheckBox showPasswordCheck;
    private JLabel loginFeedbackLabel;
    private JButton loginButton;
    private char defaultPasswordEchoChar;

    // Session state
    private UserSession currentSession;
    private JLabel sessionUserLabel;
    private final LoginRateLimiter rateLimiter = new LoginRateLimiter(5, 30_000L);

    // Report page state
    private JLabel reportHeading;
    private JLabel reportSubtitle;
    private JLabel locationLabel;
    private JLabel dateTimeLabel;
    private JTextField nameField;
    private JComboBox<String> typeField;
    private JTextField otherTypeField;
    private JPanel otherTypeRow;
    private JTextField locationField;
    private JTextField dateTimeField;
    private JTextArea appearanceArea;
    private JTextField registrationIdField;
    private JPanel conditionRow;
    private JComboBox<String> conditionField;
    private JTextField reporterField;
    private JTextField contactField;
    private String reportStatus = "LOST";

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                database = new ItemDatabase();
                Findagain app = new Findagain();
                items.clear();
                items.addAll(database.loadItems());
                app.refreshDashboard();
                app.refreshReports();
                app.refreshItemSelector();
                app.show();
            } catch (SQLException exception) {
                String message = "Could not open the local reports database:\n"
                        + exception.getMessage();
                if (exception.getMessage() != null
                        && exception.getMessage().contains("No suitable driver")) {
                    message += "\n\nThe SQLite JDBC driver is missing. On Windows, start the app "
                            + "with run.bat, or use 'mvn compile exec:java'. "
                            + "Running only 'java Findagain' does not load the database driver.";
                }
                JOptionPane.showMessageDialog(null,
                        message,
                        "Database error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void show() {
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(920, 640));
        frame.setSize(1120, 720);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        rootPanel.add(createLoginView(), "login");
        rootPanel.add(createAuthenticatedAppView(), "app");

        frame.add(rootPanel, BorderLayout.CENTER);
        rootLayout.show(rootPanel, "login");
        frame.setVisible(true);
        if (loginRegField != null) {
            loginRegField.requestFocusInWindow();
        }
    }

    private JPanel createAuthenticatedAppView() {
        JPanel appShell = new JPanel(new BorderLayout());
        appShell.add(createHeader(), BorderLayout.NORTH);
        appShell.add(createSidebar(), BorderLayout.WEST);

        content.setBackground(BACKGROUND);
        content.add(createDashboard(), "dashboard");
        content.add(createReportPage(), "report");
        content.add(createReportsPage(), "reports");
        content.add(createMatchesPage(), "matches");
        appShell.add(content, BorderLayout.CENTER);
        return appShell;
    }

    private JPanel createLoginView() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setBackground(BACKGROUND);

        // Top branding bar matching existing header
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(Color.WHITE);
        topBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(225, 231, 236)),
                BorderFactory.createEmptyBorder(18, 28, 18, 28)));

        JLabel brandTitle = new JLabel("SRM AP  |  CAMPUS LOST & FOUND");
        brandTitle.setFont(new Font("SansSerif", Font.BOLD, 19));
        brandTitle.setForeground(NAVY);
        JLabel brandSubtitle = new JLabel("Student & Campus Community Authentication Portal");
        brandSubtitle.setFont(new Font("SansSerif", Font.PLAIN, 13));
        brandSubtitle.setForeground(new Color(105, 118, 130));

        JPanel brandBox = new JPanel();
        brandBox.setOpaque(false);
        brandBox.setLayout(new BoxLayout(brandBox, BoxLayout.Y_AXIS));
        brandBox.add(brandTitle);
        brandBox.add(Box.createVerticalStrut(4));
        brandBox.add(brandSubtitle);
        topBar.add(brandBox, BorderLayout.WEST);
        outer.add(topBar, BorderLayout.NORTH);

        // Centered responsive card container
        JPanel centerCanvas = new JPanel(new GridBagLayout());
        centerCanvas.setBackground(BACKGROUND);
        centerCanvas.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));

        JPanel loginCard = new JPanel();
        loginCard.setLayout(new BoxLayout(loginCard, BoxLayout.Y_AXIS));
        loginCard.setBackground(Color.WHITE);
        loginCard.setPreferredSize(new Dimension(460, 480));
        loginCard.setMaximumSize(new Dimension(500, 580));
        loginCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(4, 0, 0, 0, TEAL),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(222, 229, 235)),
                        BorderFactory.createEmptyBorder(28, 32, 28, 32))));

        JLabel badge = new JLabel("STUDENT LOGIN");
        badge.setFont(new Font("SansSerif", Font.BOLD, 11));
        badge.setForeground(TEAL);
        badge.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginCard.add(badge);
        loginCard.add(Box.createVerticalStrut(6));

        JLabel heading = new JLabel("Sign in to your account");
        heading.setFont(new Font("SansSerif", Font.BOLD, 24));
        heading.setForeground(NAVY);
        heading.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginCard.add(heading);
        loginCard.add(Box.createVerticalStrut(6));

        JLabel subtitle = new JLabel(
                "<html>Use your SRM AP Registration Number (<b>AP</b> + 11 digits) and your Date of Birth (<b>DDMMYYYY</b>) as your initial password.</html>");
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 13));
        subtitle.setForeground(new Color(95, 108, 120));
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginCard.add(subtitle);
        loginCard.add(Box.createVerticalStrut(18));

        loginFeedbackLabel = new JLabel();
        loginFeedbackLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        loginFeedbackLabel.setOpaque(true);
        loginFeedbackLabel.setVisible(false);
        loginFeedbackLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginFeedbackLabel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 56));
        loginCard.add(loginFeedbackLabel);
        loginCard.add(Box.createVerticalStrut(10));

        // Registration Number Field
        JLabel regLabel = fieldLabel("Registration Number *");
        regLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginCard.add(regLabel);
        loginCard.add(Box.createVerticalStrut(6));

        loginRegField = createTextField("Format: AP followed by 11 digits (e.g. AP12345678901)");
        loginRegField.setName("loginRegistrationField");
        loginRegField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(204, 214, 224)),
                BorderFactory.createEmptyBorder(8, 11, 8, 11)));
        loginRegField.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginRegField.addActionListener(event -> handleLogin());
        loginCard.add(loginRegField);
        loginCard.add(Box.createVerticalStrut(16));

        // Password Field
        JLabel passLabel = fieldLabel("Password (Initial: DOB in DDMMYYYY) *");
        passLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginCard.add(passLabel);
        loginCard.add(Box.createVerticalStrut(6));

        loginPasswordField = new JPasswordField();
        loginPasswordField.setName("loginPasswordField");
        loginPasswordField.setFont(new Font("SansSerif", Font.PLAIN, 14));
        loginPasswordField.setToolTipText("Enter your Date of Birth in DDMMYYYY format");
        loginPasswordField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        loginPasswordField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(204, 214, 224)),
                BorderFactory.createEmptyBorder(8, 11, 8, 11)));
        loginPasswordField.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginPasswordField.addActionListener(event -> handleLogin());
        defaultPasswordEchoChar = loginPasswordField.getEchoChar();
        loginCard.add(loginPasswordField);
        loginCard.add(Box.createVerticalStrut(10));

        // Show / Hide Password + Forgot Password Row
        JPanel optionsRow = new JPanel(new BorderLayout());
        optionsRow.setOpaque(false);
        optionsRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        optionsRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));

        showPasswordCheck = new JCheckBox("Show Password");
        showPasswordCheck.setName("showPasswordCheck");
        showPasswordCheck.setOpaque(false);
        showPasswordCheck.setFont(new Font("SansSerif", Font.PLAIN, 12));
        showPasswordCheck.setForeground(TEXT);
        showPasswordCheck.setFocusPainted(false);
        showPasswordCheck.addActionListener(event -> {
            if (showPasswordCheck.isSelected()) {
                loginPasswordField.setEchoChar((char) 0);
            } else {
                loginPasswordField.setEchoChar(defaultPasswordEchoChar);
            }
        });
        optionsRow.add(showPasswordCheck, BorderLayout.WEST);

        JButton forgotPasswordBtn = linkButton("Forgot Password?");
        forgotPasswordBtn.setName("forgotPasswordButton");
        forgotPasswordBtn.addActionListener(event -> openForgotPasswordDialog());
        optionsRow.add(forgotPasswordBtn, BorderLayout.EAST);

        loginCard.add(optionsRow);
        loginCard.add(Box.createVerticalStrut(16));

        // Login Button
        loginButton = primaryButton("Login to Campus Portal");
        loginButton.setName("loginSubmitButton");
        loginButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        loginButton.setHorizontalAlignment(SwingConstants.CENTER);
        loginButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        loginButton.addActionListener(event -> handleLogin());
        loginCard.add(loginButton);

        loginCard.add(Box.createVerticalStrut(16));

        // First-time registration row
        JPanel registerRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        registerRow.setOpaque(false);
        registerRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        registerRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        JLabel newStudentLabel = new JLabel("First time logging in?  ");
        newStudentLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        newStudentLabel.setForeground(new Color(95, 108, 120));
        JButton registerStudentBtn = linkButton("Register Student Account");
        registerStudentBtn.setName("registerStudentButton");
        registerStudentBtn.addActionListener(event -> openStudentRegistrationDialog());
        registerRow.add(newStudentLabel);
        registerRow.add(registerStudentBtn);
        loginCard.add(registerRow);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.anchor = GridBagConstraints.CENTER;
        centerCanvas.add(loginCard, gbc);

        JScrollPane scrollPane = new JScrollPane(centerCanvas);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        outer.add(scrollPane, BorderLayout.CENTER);

        return outer;
    }

    private JButton linkButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 12));
        button.setForeground(TEAL);
        button.setContentAreaFilled(false);
        button.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return button;
    }

    private void showLoginFeedback(String message, boolean isError) {
        if (loginFeedbackLabel == null) {
            return;
        }
        loginFeedbackLabel.setText("<html>" + escapeHtml(message) + "</html>");
        loginFeedbackLabel.setBackground(isError ? ERROR_BG : SUCCESS_BG);
        loginFeedbackLabel.setForeground(isError ? ERROR_TEXT : SUCCESS_TEXT);
        loginFeedbackLabel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(isError ? ERROR_BORDER : SUCCESS_TEXT),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)));
        loginFeedbackLabel.setVisible(true);
        loginFeedbackLabel.revalidate();
        loginFeedbackLabel.repaint();
    }

    private void clearLoginFeedback() {
        if (loginFeedbackLabel != null) {
            loginFeedbackLabel.setVisible(false);
            loginFeedbackLabel.setText("");
        }
    }

    static String validateRegistrationNumber(String input) {
        if (input == null || input.trim().isEmpty()) {
            return "Please enter your Registration Number.";
        }
        String trimmed = input.trim();
        if (!trimmed.startsWith("AP")) {
            return "Invalid Registration Number: It must start with uppercase 'AP' (e.g., AP12345678901).";
        }
        if (trimmed.length() != 13) {
            return "Invalid Registration Number: Total length must be exactly 13 characters ('AP' followed by 11 digits).";
        }
        String digitsPart = trimmed.substring(2);
        for (int i = 0; i < digitsPart.length(); i++) {
            if (!Character.isDigit(digitsPart.charAt(i))) {
                return "Invalid Registration Number: Only numeric digits (0-9) are allowed after 'AP'.";
            }
        }
        if (!REGISTRATION_PATTERN.matcher(trimmed).matches()) {
            return "Invalid Registration Number format. Expected AP followed by 11 digits.";
        }
        return null;
    }

    static String normalizeDobToCompact(String dobInput) {
        if (dobInput == null) {
            return null;
        }
        String cleaned = dobInput.trim().replace("-", "").replace("/", "").replace(".", "");
        if (!DOB_PASSWORD_PATTERN.matcher(cleaned).matches()) {
            return null;
        }
        int currentYear = LocalDate.now().getYear();
        try {
            int p1 = Integer.parseInt(cleaned.substring(0, 2));
            int p2 = Integer.parseInt(cleaned.substring(2, 4));
            int yEnd = Integer.parseInt(cleaned.substring(4, 8));

            // 1. Try DDMMYYYY (e.g. 15082005 or 28122006)
            if (yEnd >= 1900 && yEnd <= currentYear && p2 >= 1 && p2 <= 12 && p1 >= 1 && p1 <= 31) {
                try {
                    LocalDate parsed = LocalDate.of(yEnd, p2, p1);
                    if (!parsed.isAfter(LocalDate.now())) {
                        return String.format("%02d%02d%04d", p1, p2, yEnd);
                    }
                } catch (DateTimeException ignored) {
                }
            }

            // 2. Try MMDDYYYY (e.g. 12282006 -> month=12, day=28, year=2006)
            if (yEnd >= 1900 && yEnd <= currentYear && p1 >= 1 && p1 <= 12 && p2 >= 1 && p2 <= 31) {
                try {
                    LocalDate parsed = LocalDate.of(yEnd, p1, p2);
                    if (!parsed.isAfter(LocalDate.now())) {
                        return String.format("%02d%02d%04d", p2, p1, yEnd);
                    }
                } catch (DateTimeException ignored) {
                }
            }

            // 3. Try YYYYMMDD (e.g. 20061228 -> year=2006, month=12, day=28)
            int yStart = Integer.parseInt(cleaned.substring(0, 4));
            int mMid = Integer.parseInt(cleaned.substring(4, 6));
            int dEnd = Integer.parseInt(cleaned.substring(6, 8));
            if (yStart >= 1900 && yStart <= currentYear && mMid >= 1 && mMid <= 12 && dEnd >= 1 && dEnd <= 31) {
                try {
                    LocalDate parsed = LocalDate.of(yStart, mMid, dEnd);
                    if (!parsed.isAfter(LocalDate.now())) {
                        return String.format("%02d%02d%04d", dEnd, mMid, yStart);
                    }
                } catch (DateTimeException ignored) {
                }
            }
        } catch (NumberFormatException ex) {
            return null;
        }
        return null;
    }

    private void handleLogin() {
        clearLoginFeedback();
        String regNumber = loginRegField.getText() != null ? loginRegField.getText().trim() : "";
        char[] passwordChars = loginPasswordField.getPassword();
        String password = new String(passwordChars);
        java.util.Arrays.fill(passwordChars, '\0');

        // 1. Frontend format validation for Registration Number
        String regError = validateRegistrationNumber(regNumber);
        if (regError != null) {
            showLoginFeedback(regError, true);
            loginRegField.requestFocusInWindow();
            return;
        }

        // 2. Frontend validation for Password presence
        if (password.isEmpty()) {
            showLoginFeedback("Please enter your password (your Date of Birth in DDMMYYYY format).", true);
            loginPasswordField.requestFocusInWindow();
            return;
        }

        // 3. Rate limit check
        long remainingLockoutMs = rateLimiter.getRemainingLockoutMs(regNumber);
        if (remainingLockoutMs > 0) {
            long seconds = Math.max(1L, (remainingLockoutMs + 999L) / 1000L);
            showLoginFeedback("Too many failed login attempts. Please wait " + seconds + " second(s) before trying again.", true);
            return;
        }

        // 4. Backend / Database authentication
        try {
            AuthenticatedUser authUser = database.authenticateUser(regNumber, password);
            if (authUser == null) {
                rateLimiter.recordFailure(regNumber);
                showLoginFeedback("Invalid Registration Number or Password.", true);
                loginPasswordField.setText("");
                return;
            }

            // Successful login
            rateLimiter.reset(regNumber);
            currentSession = new UserSession(UUID.randomUUID().toString(), authUser, System.currentTimeMillis());
            loginPasswordField.setText("");
            showPasswordCheck.setSelected(false);
            loginPasswordField.setEchoChar(defaultPasswordEchoChar);
            clearLoginFeedback();

            updateSessionHeader();
            refreshDashboard();
            refreshReports();
            refreshItemSelector();
            cardLayout.show(content, "dashboard");
            rootLayout.show(rootPanel, "app");
        } catch (SQLException exception) {
            showLoginFeedback("Authentication service error. Please try again.", true);
        }
    }

    private void handleLogout() {
        currentSession = null;
        if (loginRegField != null) {
            loginRegField.setText("");
        }
        if (loginPasswordField != null) {
            loginPasswordField.setText("");
            loginPasswordField.setEchoChar(defaultPasswordEchoChar);
        }
        if (showPasswordCheck != null) {
            showPasswordCheck.setSelected(false);
        }
        clearLoginFeedback();
        clearReportForm();
        rootLayout.show(rootPanel, "login");
        if (loginRegField != null) {
            loginRegField.requestFocusInWindow();
        }
    }

    private boolean ensureAuthenticated() {
        if (currentSession == null || currentSession.user == null) {
            rootLayout.show(rootPanel, "login");
            showLoginFeedback("Please log in with your Registration Number and Password to access this page.", true);
            return false;
        }
        return true;
    }

    private void updateSessionHeader() {
        if (sessionUserLabel != null && currentSession != null && currentSession.user != null) {
            sessionUserLabel.setText(currentSession.user.fullName + " (" + currentSession.user.registrationNumber + ")");
        }
    }

    private void openForgotPasswordDialog() {
        JDialog dialog = new JDialog(frame, "Reset / Forgot Password", true);
        dialog.setSize(450, 420);
        dialog.setLocationRelativeTo(frame);
        dialog.setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(22, 24, 22, 24));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("Reset Your Password");
        title.setFont(new Font("SansSerif", Font.BOLD, 19));
        title.setForeground(NAVY);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(title);
        panel.add(Box.createVerticalStrut(6));

        JLabel info = new JLabel(
                "<html>Verify your Registration Number and registered Date of Birth (<b>DD-MM-YYYY</b> or <b>DDMMYYYY</b>) to reset your password. Leave the new password blank to restore your DOB (DDMMYYYY) as your password.</html>");
        info.setFont(new Font("SansSerif", Font.PLAIN, 12));
        info.setForeground(new Color(95, 108, 120));
        info.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(info);
        panel.add(Box.createVerticalStrut(14));

        JTextField regField = createTextField("e.g. AP25110070127");
        if (loginRegField != null && !loginRegField.getText().trim().isEmpty()) {
            regField.setText(loginRegField.getText().trim());
        } else if (currentSession != null && currentSession.user != null) {
            regField.setText(currentSession.user.registrationNumber);
            regField.setEditable(false);
        }
        addFormField(panel, "Registration Number (AP + 11 digits) *", regField);

        JPasswordField dobField = new JPasswordField();
        dobField.setFont(new Font("SansSerif", Font.PLAIN, 14));
        dobField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        addFormField(panel, "Registered Date of Birth (DD-MM-YYYY or DDMMYYYY) *", dobField);

        JPasswordField newPassField = new JPasswordField();
        newPassField.setFont(new Font("SansSerif", Font.PLAIN, 14));
        newPassField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        addFormField(panel, "New Password (leave empty to reset to DOB DDMMYYYY)", newPassField);

        JCheckBox showChars = new JCheckBox("Show entered values");
        showChars.setOpaque(false);
        showChars.setFont(new Font("SansSerif", Font.PLAIN, 12));
        showChars.setAlignmentX(Component.LEFT_ALIGNMENT);
        char defaultEcho = dobField.getEchoChar();
        showChars.addActionListener(e -> {
            char echo = showChars.isSelected() ? (char) 0 : defaultEcho;
            dobField.setEchoChar(echo);
            newPassField.setEchoChar(echo);
        });
        panel.add(showChars);
        panel.add(Box.createVerticalStrut(14));

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttons.setOpaque(false);
        buttons.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton cancelBtn = new JButton("Cancel");
        cancelBtn.setFont(new Font("SansSerif", Font.PLAIN, 13));
        cancelBtn.addActionListener(e -> dialog.dispose());

        JButton resetBtn = primaryButton("Verify & Reset Password");
        resetBtn.addActionListener(e -> {
            String reg = regField.getText().trim();
            String regErr = validateRegistrationNumber(reg);
            if (regErr != null) {
                JOptionPane.showMessageDialog(dialog, regErr, "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String dobRaw = new String(dobField.getPassword()).trim();
            String dobCompact = normalizeDobToCompact(dobRaw);
            if (dobCompact == null) {
                JOptionPane.showMessageDialog(dialog,
                        "Please enter a valid calendar Date of Birth in DD-MM-YYYY or DDMMYYYY format.",
                        "Invalid Date of Birth", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String newPassword = new String(newPassField.getPassword()).trim();
            String targetPassword = newPassword.isEmpty() ? dobCompact : newPassword;
            if (targetPassword.length() < 6) {
                JOptionPane.showMessageDialog(dialog,
                        "Password must be at least 6 characters long.",
                        "Weak Password", JOptionPane.WARNING_MESSAGE);
                return;
            }
            try {
                boolean updated = database.resetPasswordWithDob(reg, dobCompact, targetPassword);
                if (!updated) {
                    JOptionPane.showMessageDialog(dialog,
                            "Could not verify Registration Number and Date of Birth.",
                            "Verification Failed", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                rateLimiter.reset(reg);
                JOptionPane.showMessageDialog(dialog,
                        newPassword.isEmpty()
                                ? "Your password has been reset to your Date of Birth (DDMMYYYY)."
                                : "Your password has been updated successfully.",
                        "Password Updated", JOptionPane.INFORMATION_MESSAGE);
                dialog.dispose();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(dialog,
                        "Database error while updating password.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        buttons.add(cancelBtn);
        buttons.add(resetBtn);
        panel.add(buttons);

        dialog.add(panel, BorderLayout.CENTER);
        dialog.setVisible(true);
    }

    private void openStudentRegistrationDialog() {
        JDialog dialog = new JDialog(frame, "First-Time Student Registration", true);
        dialog.setSize(470, 490);
        dialog.setLocationRelativeTo(frame);
        dialog.setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(22, 24, 22, 24));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("Register SRM AP Student Account");
        title.setFont(new Font("SansSerif", Font.BOLD, 19));
        title.setForeground(NAVY);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(title);
        panel.add(Box.createVerticalStrut(6));

        JLabel info = new JLabel(
                "<html>Your Date of Birth (<b>DDMMYYYY</b>) will be securely hashed and set as your initial login password.</html>");
        info.setFont(new Font("SansSerif", Font.PLAIN, 12));
        info.setForeground(new Color(95, 108, 120));
        info.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(info);
        panel.add(Box.createVerticalStrut(14));

        JTextField regField = createTextField("AP followed by 11 digits, e.g. AP12345678901");
        if (loginRegField != null && !loginRegField.getText().trim().isEmpty()) {
            regField.setText(loginRegField.getText().trim());
        }
        addFormField(panel, "Registration Number (AP + 11 digits) *", regField);

        JTextField fullNameField = createTextField("Your full name");
        addFormField(panel, "Full Name *", fullNameField);

        JTextField studentContactField = createTextField("Campus email or phone number");
        addFormField(panel, "Campus Email or Phone *", studentContactField);

        JTextField dobField = createTextField("DD-MM-YYYY (e.g. 15-08-2005)");
        addFormField(panel, "Date of Birth (DD-MM-YYYY) *", dobField);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttons.setOpaque(false);
        buttons.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton cancelBtn = new JButton("Cancel");
        cancelBtn.setFont(new Font("SansSerif", Font.PLAIN, 13));
        cancelBtn.addActionListener(e -> dialog.dispose());

        JButton registerBtn = primaryButton("Register Account");
        registerBtn.addActionListener(e -> {
            String reg = regField.getText().trim();
            String regErr = validateRegistrationNumber(reg);
            if (regErr != null) {
                JOptionPane.showMessageDialog(dialog, regErr, "Invalid Registration Number", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String fullName = fullNameField.getText().trim();
            String contactVal = studentContactField.getText().trim();
            String dobRaw = dobField.getText().trim();
            if (fullName.isEmpty() || contactVal.isEmpty() || dobRaw.isEmpty()) {
                JOptionPane.showMessageDialog(dialog,
                        "Please complete all required fields.",
                        "Missing Information", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String dobCompact = normalizeDobToCompact(dobRaw);
            if (dobCompact == null) {
                JOptionPane.showMessageDialog(dialog,
                        "Please enter a valid calendar Date of Birth in DD-MM-YYYY or DDMMYYYY format (e.g. 15-08-2005).",
                        "Invalid Date of Birth", JOptionPane.WARNING_MESSAGE);
                return;
            }
            try {
                if (database.userExists(reg)) {
                    JOptionPane.showMessageDialog(dialog,
                            "An account for Registration Number " + reg + " is already registered. Please sign in.",
                            "Already Registered", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                database.registerUser(reg, fullName, contactVal, dobCompact);
                if (loginRegField != null) {
                    loginRegField.setText(reg);
                }
                showLoginFeedback("Account registered for " + reg + ". Log in using your DOB in DDMMYYYY format.", false);
                dialog.dispose();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(dialog,
                        "Could not register account: " + ex.getMessage(),
                        "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        buttons.add(cancelBtn);
        buttons.add(registerBtn);
        panel.add(buttons);

        dialog.add(panel, BorderLayout.CENTER);
        dialog.setVisible(true);
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setBorder(BorderFactory.createEmptyBorder(18, 26, 18, 26));

        JLabel title = new JLabel("SRM AP  |  CAMPUS LOST & FOUND");
        title.setFont(new Font("SansSerif", Font.BOLD, 19));
        title.setForeground(NAVY);
        JLabel subtitle = new JLabel("A simple way to report and reunite with your belongings");
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 13));
        subtitle.setForeground(new Color(105, 118, 130));

        JPanel titles = new JPanel();
        titles.setOpaque(false);
        titles.setLayout(new BoxLayout(titles, BoxLayout.Y_AXIS));
        titles.add(title);
        titles.add(Box.createVerticalStrut(5));
        titles.add(subtitle);
        header.add(titles, BorderLayout.CENTER);

        // User session controls on the right
        JPanel sessionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 4));
        sessionPanel.setOpaque(false);

        sessionUserLabel = new JLabel("");
        sessionUserLabel.setFont(new Font("SansSerif", Font.BOLD, 13));
        sessionUserLabel.setForeground(NAVY);
        sessionPanel.add(sessionUserLabel);

        JButton changePassBtn = new JButton("Change Password");
        changePassBtn.setFont(new Font("SansSerif", Font.PLAIN, 12));
        changePassBtn.setForeground(NAVY);
        changePassBtn.setBackground(new Color(235, 241, 246));
        changePassBtn.setFocusPainted(false);
        changePassBtn.setBorder(BorderFactory.createEmptyBorder(7, 11, 7, 11));
        changePassBtn.addActionListener(e -> {
            if (ensureAuthenticated()) {
                openForgotPasswordDialog();
            }
        });
        sessionPanel.add(changePassBtn);

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setName("logoutButton");
        logoutBtn.setFont(new Font("SansSerif", Font.BOLD, 12));
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setBackground(NAVY);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBorder(BorderFactory.createEmptyBorder(7, 13, 7, 13));
        logoutBtn.addActionListener(e -> handleLogout());
        sessionPanel.add(logoutBtn);

        header.add(sessionPanel, BorderLayout.EAST);
        header.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(225, 231, 236)),
                BorderFactory.createEmptyBorder(18, 26, 18, 26)));
        return header;
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setBackground(NAVY);
        sidebar.setPreferredSize(new Dimension(205, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(22, 14, 18, 14));
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));

        JLabel menuLabel = new JLabel("MENU");
        menuLabel.setForeground(new Color(174, 193, 210));
        menuLabel.setFont(new Font("SansSerif", Font.BOLD, 11));
        menuLabel.setBorder(BorderFactory.createEmptyBorder(0, 12, 12, 0));
        menuLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        sidebar.add(menuLabel);
        sidebar.add(navButton("  Dashboard", "dashboard"));
        sidebar.add(navButton("  Report an item", "report"));
        sidebar.add(navButton("  All reports", "reports"));
        sidebar.add(navButton("  Find a match", "matches"));
        sidebar.add(Box.createVerticalGlue());

        JLabel campus = new JLabel("<html><b>SRM University-AP</b><br>Andhra Pradesh</html>");
        campus.setForeground(Color.WHITE);
        campus.setFont(new Font("SansSerif", Font.PLAIN, 12));
        campus.setBorder(BorderFactory.createEmptyBorder(12, 12, 0, 0));
        campus.setAlignmentX(Component.LEFT_ALIGNMENT);
        sidebar.add(campus);
        return sidebar;
    }

    private JButton navButton(String label, String card) {
        JButton button = new JButton(label);
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 43));
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        button.setForeground(Color.WHITE);
        button.setBackground(NAVY);
        button.setFont(new Font("SansSerif", Font.PLAIN, 14));
        button.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 8));
        button.setFocusPainted(false);
        button.addActionListener(event -> {
            if (!ensureAuthenticated()) {
                return;
            }
            if ("report".equals(card)) {
                openReportForm("LOST");
            } else if ("reports".equals(card)) {
                refreshReports();
            } else if ("matches".equals(card)) {
                refreshItemSelector();
                matchResults.setText("Select one of your reports, then choose Find possible matches.");
            }
            cardLayout.show(content, card);
        });
        return button;
    }

    private JPanel createDashboard() {
        JPanel page = createPage();
        page.add(dashboardWelcome());

        JPanel stats = new JPanel(new GridLayout(1, 2, 16, 0));
        stats.setOpaque(false);
        stats.setMaximumSize(new Dimension(Integer.MAX_VALUE, 125));
        stats.add(statCard("LOST ITEM REPORTS", "Waiting to be reunited", lostCount,
                new Color(255, 246, 231), new Color(205, 132, 40)));
        stats.add(statCard("FOUND ITEM REPORTS", "Ready to find their owners", foundCount,
                new Color(229, 247, 244), TEAL));
        stats.setAlignmentX(Component.LEFT_ALIGNMENT);
        page.add(Box.createVerticalStrut(20));
        page.add(stats);

        JPanel actions = new JPanel(new GridLayout(1, 2, 16, 0));
        actions.setOpaque(false);
        actions.setMaximumSize(new Dimension(Integer.MAX_VALUE, 155));
        actions.setAlignmentX(Component.LEFT_ALIGNMENT);
        actions.add(actionCard("Lost something?", "Tell the campus community where and when you last saw it.",
                "Report a lost item",
                () -> openReportForm("LOST")));
        actions.add(actionCard("Found something?", "Share its location and help it get back to its owner.",
                "Report a found item",
                () -> openReportForm("FOUND")));
        page.add(Box.createVerticalStrut(18));
        page.add(actions);

        JLabel tip = new JLabel("<html><b>Quick tip</b>&nbsp;&nbsp; Include the item type, campus location, time, and appearance to improve matching.</html>");
        tip.setFont(new Font("SansSerif", Font.PLAIN, 13));
        tip.setForeground(NAVY);
        tip.setOpaque(true);
        tip.setBackground(new Color(233, 239, 247));
        tip.setBorder(BorderFactory.createEmptyBorder(13, 16, 13, 16));
        tip.setAlignmentX(Component.LEFT_ALIGNMENT);
        page.add(tip);
        return page;
    }

    private JPanel dashboardWelcome() {
        JPanel banner = new JPanel();
        banner.setLayout(new BoxLayout(banner, BoxLayout.Y_AXIS));
        banner.setBackground(NAVY);
        banner.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 5, 0, 0, TEAL),
                BorderFactory.createEmptyBorder(20, 22, 20, 22)));
        banner.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel eyebrow = new JLabel("SRM UNIVERSITY-AP  |  CAMPUS COMMUNITY");
        eyebrow.setFont(new Font("SansSerif", Font.BOLD, 11));
        eyebrow.setForeground(new Color(142, 213, 208));
        JLabel heading = new JLabel("Lost something? Found something?");
        heading.setFont(new Font("SansSerif", Font.BOLD, 24));
        heading.setForeground(Color.WHITE);
        JLabel subtitle = new JLabel("Report it here and help belongings find their way back to their owners.");
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 14));
        subtitle.setForeground(new Color(220, 229, 238));
        banner.add(eyebrow);
        banner.add(Box.createVerticalStrut(9));
        banner.add(heading);
        banner.add(Box.createVerticalStrut(6));
        banner.add(subtitle);
        return banner;
    }

    private JPanel statCard(String title, String subtitle, JLabel count, Color color, Color accent) {
        JPanel card = new JPanel();
        card.setBackground(color);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 4, 0, 0, accent),
                BorderFactory.createEmptyBorder(13, 17, 13, 17)));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        JLabel heading = new JLabel(title);
        heading.setFont(new Font("SansSerif", Font.BOLD, 12));
        heading.setForeground(NAVY);
        JLabel detail = new JLabel(subtitle);
        detail.setFont(new Font("SansSerif", Font.PLAIN, 12));
        detail.setForeground(new Color(90, 104, 117));
        count.setFont(new Font("SansSerif", Font.BOLD, 32));
        count.setForeground(NAVY);
        card.add(heading);
        card.add(Box.createVerticalStrut(4));
        card.add(detail);
        card.add(Box.createVerticalStrut(5));
        card.add(count);
        return card;
    }

    private JPanel actionCard(String title, String detail, String buttonText, Runnable action) {
        JPanel card = new JPanel();
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 4, 0, 0, TEAL),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(226, 232, 237)),
                        BorderFactory.createEmptyBorder(15, 17, 15, 17))));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        JLabel heading = new JLabel(title);
        heading.setFont(new Font("SansSerif", Font.BOLD, 17));
        heading.setForeground(NAVY);
        JLabel description = new JLabel(detail);
        description.setFont(new Font("SansSerif", Font.PLAIN, 13));
        description.setForeground(new Color(105, 118, 130));
        JButton button = primaryButton(buttonText);
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        button.addActionListener(event -> action.run());
        card.add(heading);
        card.add(Box.createVerticalStrut(5));
        card.add(description);
        card.add(Box.createVerticalStrut(13));
        card.add(button);
        return card;
    }

    private JPanel createReportPage() {
        JPanel page = createPage();
        JPanel title = pageTitle("", "");
        reportHeading = (JLabel) title.getComponent(0);
        reportSubtitle = (JLabel) title.getComponent(2);
        page.add(title);

        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setBackground(Color.WHITE);
        form.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(226, 232, 237)),
                BorderFactory.createEmptyBorder(20, 22, 20, 22)));
        form.setAlignmentX(Component.LEFT_ALIGNMENT);

        nameField = createTextField("e.g. Black backpack, student ID card");
        addFormField(form, "Item name *", nameField);

        typeField = new JComboBox<>(new String[]{
            "Select item type", "Electronics", "ID card", "Bag", "Clothing",
            "Keys", "Water bottle", "Books / stationery", "Accessories", "Other"
        });
        typeField.setFont(new Font("SansSerif", Font.PLAIN, 14));
        addFormField(form, "Type of item *", typeField);

        otherTypeField = createTextField("Specify the item type");
        otherTypeRow = createFormField("Specify item type *", otherTypeField);
        otherTypeRow.setVisible(false);
        form.add(otherTypeRow);
        typeField.addActionListener(event ->
                otherTypeRow.setVisible("Other".equals(typeField.getSelectedItem())));

        locationLabel = fieldLabel("Where on campus? *");
        locationField = createTextField("e.g. Library, first floor, near the east entrance");
        addFormField(form, locationLabel, locationField);

        dateTimeLabel = fieldLabel("When? *");
        dateTimeField = createTextField("Date and approximate time, e.g. 7 Nov, around 2:30 PM");
        addFormField(form, dateTimeLabel, dateTimeField);

        appearanceArea = createTextArea(
                "Color, size, brand, shape, pattern, or unique marks");
        addFormField(form, "Appearance / identifying features *", appearanceArea);

        registrationIdField = createTextField("Your SRM AP registration number, e.g. AP12345678901");
        addFormField(form, "Your SRM AP Registration ID *", registrationIdField);

        conditionField = new JComboBox<>(new String[]{
            "Not specified", "Good", "Worn", "Damaged"
        });
        conditionField.setFont(new Font("SansSerif", Font.PLAIN, 14));
        conditionRow = createFormField(fieldLabel("Condition (if known)"), conditionField);
        form.add(conditionRow);

        reporterField = createTextField("Name of the person reporting this item");
        addFormField(form, "Your name *", reporterField);
        contactField = createTextField("Campus email or phone for arranging a handover");
        addFormField(form, "Campus email or phone *", contactField);

        JButton submit = primaryButton("Submit report");
        submit.setName("submitReportButton");
        submit.addActionListener(event -> submitReport());
        submit.setAlignmentX(Component.LEFT_ALIGNMENT);
        submit.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        form.add(Box.createVerticalStrut(8));
        form.add(submit);

        JLabel privacyNote = new JLabel(
                "Reports, registration IDs, and contact details are saved locally in the project database.");
        privacyNote.setFont(new Font("SansSerif", Font.PLAIN, 11));
        privacyNote.setForeground(new Color(105, 118, 130));
        privacyNote.setAlignmentX(Component.LEFT_ALIGNMENT);
        form.add(Box.createVerticalStrut(12));
        form.add(privacyNote);

        page.add(Box.createVerticalStrut(18));
        JScrollPane formScroll = new JScrollPane(form);
        formScroll.setBorder(BorderFactory.createEmptyBorder());
        formScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        page.add(formScroll);
        return page;
    }

    private JTextField createTextField(String hint) {
        JTextField field = new JTextField();
        field.setFont(new Font("SansSerif", Font.PLAIN, 14));
        field.setToolTipText(hint);
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        return field;
    }

    private JTextArea createTextArea(String hint) {
        JTextArea area = new JTextArea(3, 30);
        area.setFont(new Font("SansSerif", Font.PLAIN, 14));
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setToolTipText(hint);
        return area;
    }

    private void addFormField(JPanel form, String label, JComponent input) {
        addFormField(form, fieldLabel(label), input);
    }

    private void addFormField(JPanel form, JLabel label, JComponent input) {
        form.add(createFormField(label, input));
    }

    private JPanel createFormField(String label, JComponent input) {
        return createFormField(fieldLabel(label), input);
    }

    private JPanel createFormField(JLabel label, JComponent input) {
        JPanel row = new JPanel();
        row.setLayout(new BoxLayout(row, BoxLayout.Y_AXIS));
        row.setOpaque(false);
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        row.add(label);
        row.add(Box.createVerticalStrut(6));

        if (input instanceof JTextArea) {
            JScrollPane scrollPane = new JScrollPane(input);
            scrollPane.setPreferredSize(new Dimension(350, 78));
            scrollPane.setAlignmentX(Component.LEFT_ALIGNMENT);
            row.add(scrollPane);
        } else {
            input.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
            input.setAlignmentX(Component.LEFT_ALIGNMENT);
            row.add(input);
        }
        row.add(Box.createVerticalStrut(12));
        return row;
    }

    private JLabel fieldLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(TEXT);
        label.setFont(new Font("SansSerif", Font.BOLD, 13));
        return label;
    }

    private JPanel createReportsPage() {
        JPanel page = createPage();
        page.add(pageTitle("All item reports", "Browse reports saved in the local database on this device."));
        JTable table = new JTable(tableModel);
        table.setRowHeight(28);
        table.setAutoCreateRowSorter(true);
        table.setFillsViewportHeight(true);
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setAlignmentX(Component.LEFT_ALIGNMENT);
        page.add(Box.createVerticalStrut(18));
        page.add(scrollPane);
        return page;
    }

    private JPanel createMatchesPage() {
        JPanel page = createPage();
        page.add(pageTitle("Find a possible match", "Compare a report with reports of the opposite status."));

        JPanel controls = new JPanel(new BorderLayout(12, 0));
        controls.setOpaque(false);
        controls.setAlignmentX(Component.LEFT_ALIGNMENT);
        itemSelector.setFont(new Font("SansSerif", Font.PLAIN, 14));
        controls.add(itemSelector, BorderLayout.CENTER);
        JButton search = primaryButton("Find possible matches");
        search.addActionListener(event -> searchMatches());
        controls.add(search, BorderLayout.EAST);
        page.add(Box.createVerticalStrut(18));
        page.add(controls);

        matchResults.setEditable(false);
        matchResults.setFont(new Font("SansSerif", Font.PLAIN, 14));
        matchResults.setForeground(TEXT);
        matchResults.setBackground(Color.WHITE);
        matchResults.setLineWrap(true);
        matchResults.setWrapStyleWord(true);
        matchResults.setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));
        JScrollPane resultScroll = new JScrollPane(matchResults);
        resultScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        page.add(Box.createVerticalStrut(14));
        page.add(resultScroll);
        return page;
    }

    private JPanel createPage() {
        JPanel page = new JPanel();
        page.setBackground(BACKGROUND);
        page.setBorder(BorderFactory.createEmptyBorder(26, 28, 26, 28));
        page.setLayout(new BoxLayout(page, BoxLayout.Y_AXIS));
        return page;
    }

    private JPanel pageTitle(String title, String subtitle) {
        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel heading = new JLabel(title);
        heading.setFont(new Font("SansSerif", Font.BOLD, 23));
        heading.setForeground(NAVY);
        JLabel detail = new JLabel(subtitle);
        detail.setFont(new Font("SansSerif", Font.PLAIN, 13));
        detail.setForeground(new Color(105, 118, 130));
        panel.add(heading);
        panel.add(Box.createVerticalStrut(6));
        panel.add(detail);
        return panel;
    }

    private JButton primaryButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(TEAL);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("SansSerif", Font.BOLD, 13));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        return button;
    }

    private void openReportForm(String status) {
        if (!ensureAuthenticated()) {
            return;
        }
        reportStatus = status;
        boolean found = "FOUND".equals(status);
        reportHeading.setText(found ? "Report a found item" : "Report a lost item");
        reportSubtitle.setText(found
                ? "Share where and when you found it so its owner can identify it."
                : "Tell us when and where you last saw it to help find a match.");
        locationLabel.setText(found ? "Where did you find it? *" : "Where did you last see it? *");
        dateTimeLabel.setText(found ? "When did you find it? *" : "When did you last see it? *");
        conditionRow.setVisible(found);
        clearReportForm();
        content.revalidate();
        content.repaint();
        cardLayout.show(content, "report");
    }

    private void submitReport() {
        if (!ensureAuthenticated()) {
            return;
        }
        String name = nameField.getText().trim();
        String selectedType = (String) typeField.getSelectedItem();
        String category = "Other".equals(selectedType)
                ? otherTypeField.getText().trim() : selectedType;
        String location = locationField.getText().trim();
        String dateTime = dateTimeField.getText().trim();
        String appearance = appearanceArea.getText().trim();
        String registrationId = registrationIdField.getText().trim();
        String condition = "FOUND".equals(reportStatus)
                ? (String) conditionField.getSelectedItem() : "Not specified";
        String reporter = reporterField.getText().trim();
        String contact = contactField.getText().trim();
        if (name.isEmpty() || selectedType == null || "Select item type".equals(selectedType)
                || category.isEmpty() || location.isEmpty() || dateTime.isEmpty()
                || appearance.isEmpty() || registrationId.isEmpty()
                || reporter.isEmpty() || contact.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please complete all fields marked with *.",
                    "Missing information",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        String regValidationError = validateRegistrationNumber(registrationId);
        if (regValidationError != null) {
            JOptionPane.showMessageDialog(frame, regValidationError,
                    "Invalid Registration Number",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        Item unsavedItem = new Item(0, reportStatus, name, category, location,
                dateTime, appearance, condition, registrationId, reporter, contact);
        Item item;
        try {
            item = database.saveItem(unsavedItem);
        } catch (SQLException exception) {
            JOptionPane.showMessageDialog(frame,
                    "The report could not be saved. Please try again.\n" + exception.getMessage(),
                    "Database error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        items.add(item);
        clearReportForm();
        refreshDashboard();
        refreshReports();
        refreshItemSelector();

        List<Item> matches = findMatches(item);
        String message = "Your " + reportStatus.toLowerCase() + " report was submitted (ID " + item.id + ").";
        if (!matches.isEmpty()) {
            message += "\n\nPossible match(es) found: " + matches.size()
                    + ". Open Find a match to review them.";
        }
        JOptionPane.showMessageDialog(frame, message, "Report submitted", JOptionPane.INFORMATION_MESSAGE);
        cardLayout.show(content, "dashboard");
    }

    private void clearReportForm() {
        nameField.setText("");
        typeField.setSelectedIndex(0);
        otherTypeField.setText("");
        locationField.setText("");
        dateTimeField.setText("");
        appearanceArea.setText("");
        conditionField.setSelectedIndex(0);
        if (currentSession != null && currentSession.user != null) {
            registrationIdField.setText(currentSession.user.registrationNumber);
            reporterField.setText(currentSession.user.fullName);
            contactField.setText(currentSession.user.contact);
        } else {
            registrationIdField.setText("");
            reporterField.setText("");
            contactField.setText("");
        }
    }

    private void refreshDashboard() {
        int lost = 0;
        int found = 0;
        for (Item item : items) {
            if ("LOST".equals(item.status)) {
                lost++;
            } else {
                found++;
            }
        }
        lostCount.setText(String.valueOf(lost));
        foundCount.setText(String.valueOf(found));
    }

    private void refreshReports() {
        tableModel.setRowCount(0);
        for (Item item : items) {
            tableModel.addRow(new Object[]{item.id, item.status, item.name,
                    item.category, item.location, item.dateTime, item.appearance, item.condition,
                    item.registrationId, item.reporter, item.contact});
        }
    }

    private void refreshItemSelector() {
        itemSelector.removeAllItems();
        for (Item item : items) {
            itemSelector.addItem(item);
        }
    }

    private void searchMatches() {
        if (!ensureAuthenticated()) {
            return;
        }
        Item selected = (Item) itemSelector.getSelectedItem();
        if (selected == null) {
            matchResults.setText("Submit a lost or found report first to search for matches.");
            return;
        }
        List<Item> matches = findMatches(selected);
        if (matches.isEmpty()) {
            matchResults.setText("No possible matches found for:\n" + selected + "\n\n"
                    + "Matches are suggestions only. Check identifying details before claiming an item.");
            return;
        }
        StringBuilder text = new StringBuilder("Possible matches for ")
                .append(selected).append(":\n\n");
        for (Item match : matches) {
            text.append(match).append("\n")
                    .append("Type: ").append(match.category)
                    .append(" | When: ").append(match.dateTime).append("\n")
                    .append("Appearance: ").append(match.appearance)
                    .append(" | Condition: ").append(match.condition).append("\n")
                    .append("Registration ID: ").append(match.registrationId).append("\n")
                    .append("Contact: ").append(match.reporter)
                    .append(" (").append(match.contact).append(")\n\n");
        }
        text.append("Matches are suggestions only. Verify ownership in person.");
        matchResults.setText(text.toString());
        matchResults.setCaretPosition(0);
    }

    private static List<Item> findMatches(Item selected) {
        List<Item> matches = new ArrayList<>();
        for (Item candidate : items) {
            if (candidate.id != selected.id
                    && !candidate.status.equals(selected.status)
                    && getMatchScore(selected, candidate) >= 2) {
                matches.add(candidate);
            }
        }
        return matches;
    }

    private static int getMatchScore(Item first, Item second) {
        int score = 0;
        if (first.category.equalsIgnoreCase(second.category)) {
            score++;
        }
        if (hasCommonWord(first.appearance, second.appearance)) {
            score++;
        }
        if (first.name.equalsIgnoreCase(second.name)) {
            score += 2;
        }
        if (first.location.equalsIgnoreCase(second.location)) {
            score++;
        }
        return score;
    }

    private static boolean hasCommonWord(String first, String second) {
        String[] firstWords = first.toLowerCase().split("\\W+");
        String secondText = " " + second.toLowerCase() + " ";
        for (String word : firstWords) {
            if (word.length() > 2 && secondText.contains(" " + word + " ")) {
                return true;
            }
        }
        return false;
    }

    private static String escapeHtml(String text) {
        if (text == null) {
            return "";
        }
        return text.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;");
    }

    static final class PasswordHasher {
        private static final String ALGORITHM = "PBKDF2WithHmacSHA256";
        private static final int ITERATIONS = 65536;
        private static final int KEY_LENGTH = 256;
        private static final int SALT_BYTES = 16;
        private static final SecureRandom RANDOM = new SecureRandom();

        static String generateSalt() {
            byte[] salt = new byte[SALT_BYTES];
            RANDOM.nextBytes(salt);
            return Base64.getEncoder().encodeToString(salt);
        }

        static String hashSecret(String secret, String base64Salt) {
            try {
                byte[] salt = Base64.getDecoder().decode(base64Salt);
                PBEKeySpec spec = new PBEKeySpec(secret.toCharArray(), salt, ITERATIONS, KEY_LENGTH);
                try {
                    SecretKeyFactory factory = SecretKeyFactory.getInstance(ALGORITHM);
                    byte[] hash = factory.generateSecret(spec).getEncoded();
                    return Base64.getEncoder().encodeToString(hash);
                } finally {
                    spec.clearPassword();
                }
            } catch (NoSuchAlgorithmException | InvalidKeySpecException ex) {
                throw new IllegalStateException("Password hashing algorithm unavailable", ex);
            }
        }

        static boolean verifySecret(String candidateSecret, String base64Salt, String expectedBase64Hash) {
            String candidateHash = hashSecret(candidateSecret, base64Salt);
            byte[] a = candidateHash.getBytes(java.nio.charset.StandardCharsets.UTF_8);
            byte[] b = expectedBase64Hash.getBytes(java.nio.charset.StandardCharsets.UTF_8);
            return MessageDigest.isEqual(a, b);
        }
    }

    static final class LoginRateLimiter {
        private final int maxAttempts;
        private final long lockoutDurationMs;
        private final Map<String, AttemptRecord> attemptsByReg = new HashMap<>();

        LoginRateLimiter(int maxAttempts, long lockoutDurationMs) {
            this.maxAttempts = maxAttempts;
            this.lockoutDurationMs = lockoutDurationMs;
        }

        synchronized long getRemainingLockoutMs(String regNumber) {
            AttemptRecord rec = attemptsByReg.get(regNumber);
            if (rec == null || rec.lockedUntilMs <= 0) {
                return 0L;
            }
            long now = System.currentTimeMillis();
            if (now >= rec.lockedUntilMs) {
                attemptsByReg.remove(regNumber);
                return 0L;
            }
            return rec.lockedUntilMs - now;
        }

        synchronized void recordFailure(String regNumber) {
            long now = System.currentTimeMillis();
            AttemptRecord rec = attemptsByReg.get(regNumber);
            if (rec == null || (rec.lockedUntilMs > 0 && now >= rec.lockedUntilMs)) {
                rec = new AttemptRecord();
                attemptsByReg.put(regNumber, rec);
            }
            rec.failedCount++;
            if (rec.failedCount >= maxAttempts) {
                rec.lockedUntilMs = now + lockoutDurationMs;
            }
        }

        synchronized void reset(String regNumber) {
            attemptsByReg.remove(regNumber);
        }

        private static final class AttemptRecord {
            int failedCount;
            long lockedUntilMs;
        }
    }

    static final class AuthenticatedUser {
        final String registrationNumber;
        final String fullName;
        final String contact;

        AuthenticatedUser(String registrationNumber, String fullName, String contact) {
            this.registrationNumber = registrationNumber;
            this.fullName = fullName;
            this.contact = contact;
        }
    }

    private static final class UserSession {
        final String token;
        final AuthenticatedUser user;
        final long createdAtMs;

        UserSession(String token, AuthenticatedUser user, long createdAtMs) {
            this.token = token;
            this.user = user;
            this.createdAtMs = createdAtMs;
        }
    }

    static class ItemDatabase {
        private static final String DATABASE_URL = "jdbc:sqlite:data/srm-ap-lost-found.db";
        private static final String DUMMY_SALT = PasswordHasher.generateSalt();
        private static final String DUMMY_HASH = PasswordHasher.hashSecret("00000000", DUMMY_SALT);

        ItemDatabase() throws SQLException {
            java.io.File dataDirectory = new java.io.File("data");
            if (!dataDirectory.exists() && !dataDirectory.mkdirs()) {
                throw new SQLException("Could not create the data directory.");
            }

            try (Connection connection = DriverManager.getConnection(DATABASE_URL);
                 Statement statement = connection.createStatement()) {
                statement.executeUpdate(
                        "CREATE TABLE IF NOT EXISTS item_reports ("
                        + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + "status TEXT NOT NULL, "
                        + "item_name TEXT NOT NULL, "
                        + "category TEXT NOT NULL, "
                        + "location TEXT NOT NULL, "
                        + "date_time TEXT NOT NULL, "
                        + "appearance TEXT NOT NULL, "
                        + "condition TEXT NOT NULL, "
                        + "registration_id TEXT NOT NULL, "
                        + "reporter TEXT NOT NULL, "
                        + "contact TEXT NOT NULL"
                        + ")");

                statement.executeUpdate(
                        "CREATE TABLE IF NOT EXISTS users ("
                        + "registration_number TEXT PRIMARY KEY, "
                        + "full_name TEXT NOT NULL, "
                        + "contact TEXT NOT NULL, "
                        + "dob_hash TEXT NOT NULL, "
                        + "password_hash TEXT NOT NULL, "
                        + "password_salt TEXT NOT NULL, "
                        + "created_at TEXT NOT NULL"
                        + ")");
            }
            seedExistingAndDefaultUsers();
        }

        private void seedExistingAndDefaultUsers() throws SQLException {
            List<String[]> existingReporters = new ArrayList<>();
            String query = "SELECT DISTINCT registration_id, reporter, contact FROM item_reports";
            try (Connection connection = DriverManager.getConnection(DATABASE_URL);
                 Statement statement = connection.createStatement();
                 ResultSet rs = statement.executeQuery(query)) {
                while (rs.next()) {
                    String regId = rs.getString("registration_id");
                    String reporter = rs.getString("reporter");
                    String contact = rs.getString("contact");
                    if (regId != null && REGISTRATION_PATTERN.matcher(regId.trim()).matches()) {
                        existingReporters.add(new String[]{regId.trim(), reporter, contact});
                    }
                }
            }
            for (String[] rep : existingReporters) {
                if (!userExists(rep[0])) {
                    registerUser(rep[0], rep[1], rep[2], "15082005");
                }
            }
            if (!userExists("AP12345678901")) {
                registerUser("AP12345678901", "SRM AP Student", "student@srmap.edu.in", "15082005");
            }
            if (!userExists("AP25110071048")) {
                registerUser("AP25110071048", "SRM AP Student", "student@srmap.edu.in", "28122006");
            }
        }

        boolean userExists(String registrationNumber) throws SQLException {
            String sql = "SELECT 1 FROM users WHERE registration_number = ?";
            try (Connection connection = DriverManager.getConnection(DATABASE_URL);
                 PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, registrationNumber);
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next();
                }
            }
        }

        void registerUser(String registrationNumber, String fullName, String contact, String dobCompact)
                throws SQLException {
            String regError = validateRegistrationNumber(registrationNumber);
            if (regError != null) {
                throw new SQLException(regError);
            }
            String normalizedDob = normalizeDobToCompact(dobCompact);
            if (normalizedDob == null) {
                throw new SQLException("Invalid Date of Birth format. Expected DDMMYYYY.");
            }
            String salt = PasswordHasher.generateSalt();
            String dobHash = PasswordHasher.hashSecret(normalizedDob, salt);
            String sql = "INSERT INTO users (registration_number, full_name, contact, dob_hash, password_hash, password_salt, created_at) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (Connection connection = DriverManager.getConnection(DATABASE_URL);
                 PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, registrationNumber.trim());
                ps.setString(2, fullName.trim());
                ps.setString(3, contact.trim());
                ps.setString(4, dobHash);
                ps.setString(5, dobHash);
                ps.setString(6, salt);
                ps.setString(7, LocalDate.now().toString());
                ps.executeUpdate();
            }
        }

        AuthenticatedUser authenticateUser(String registrationNumber, String password) throws SQLException {
            if (validateRegistrationNumber(registrationNumber) != null || password == null || password.isEmpty()) {
                return null;
            }
            String trimmedReg = registrationNumber.trim();
            String normalizedDobCandidate = normalizeDobToCompact(password);

            String sql = "SELECT registration_number, full_name, contact, password_hash, password_salt "
                    + "FROM users WHERE registration_number = ?";
            try (Connection connection = DriverManager.getConnection(DATABASE_URL);
                 PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, trimmedReg);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        if (normalizedDobCandidate != null) {
                            String[] existingInfo = findReporterInfo(connection, trimmedReg);
                            registerUser(trimmedReg, existingInfo[0], existingInfo[1], normalizedDobCandidate);
                            return new AuthenticatedUser(trimmedReg, existingInfo[0], existingInfo[1]);
                        }
                        PasswordHasher.verifySecret(password, DUMMY_SALT, DUMMY_HASH);
                        return null;
                    }
                    String fullName = rs.getString("full_name");
                    String contact = rs.getString("contact");
                    String storedHash = rs.getString("password_hash");
                    String storedSalt = rs.getString("password_salt");

                    boolean matched = PasswordHasher.verifySecret(password, storedSalt, storedHash);
                    if (!matched && normalizedDobCandidate != null) {
                        matched = PasswordHasher.verifySecret(normalizedDobCandidate, storedSalt, storedHash);
                        if (!matched) {
                            String newSalt = PasswordHasher.generateSalt();
                            String newHash = PasswordHasher.hashSecret(normalizedDobCandidate, newSalt);
                            try (PreparedStatement ups = connection.prepareStatement(
                                    "UPDATE users SET dob_hash = ?, password_hash = ?, password_salt = ? WHERE registration_number = ?")) {
                                ups.setString(1, newHash);
                                ups.setString(2, newHash);
                                ups.setString(3, newSalt);
                                ups.setString(4, trimmedReg);
                                ups.executeUpdate();
                            }
                            matched = true;
                        }
                    }
                    if (!matched) {
                        return null;
                    }
                    return new AuthenticatedUser(trimmedReg, fullName, contact);
                }
            }
        }

        private String[] findReporterInfo(Connection connection, String registrationNumber) throws SQLException {
            String query = "SELECT reporter, contact FROM item_reports WHERE registration_id = ? LIMIT 1";
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                ps.setString(1, registrationNumber);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        String rep = rs.getString("reporter");
                        String con = rs.getString("contact");
                        return new String[]{
                            (rep != null && !rep.trim().isEmpty()) ? rep.trim() : "Student " + registrationNumber,
                            (con != null) ? con.trim() : ""
                        };
                    }
                }
            }
            return new String[]{"Student " + registrationNumber, ""};
        }

        boolean resetPasswordWithDob(String registrationNumber, String dobCompact, String newPassword)
                throws SQLException {
            if (validateRegistrationNumber(registrationNumber) != null) {
                return false;
            }
            String normalizedDob = normalizeDobToCompact(dobCompact);
            if (normalizedDob == null || newPassword == null || newPassword.isEmpty()) {
                return false;
            }
            String selectSql = "SELECT dob_hash, password_salt FROM users WHERE registration_number = ?";
            try (Connection connection = DriverManager.getConnection(DATABASE_URL);
                 PreparedStatement ps = connection.prepareStatement(selectSql)) {
                ps.setString(1, registrationNumber.trim());
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        PasswordHasher.verifySecret(normalizedDob, DUMMY_SALT, DUMMY_HASH);
                        return false;
                    }
                    String dobHash = rs.getString("dob_hash");
                    String salt = rs.getString("password_salt");
                    if (!PasswordHasher.verifySecret(normalizedDob, salt, dobHash)) {
                        return false;
                    }
                }
            }

            String newSalt = PasswordHasher.generateSalt();
            String newDobHash = PasswordHasher.hashSecret(normalizedDob, newSalt);
            String newPasswordHash = PasswordHasher.hashSecret(newPassword, newSalt);
            String updateSql = "UPDATE users SET dob_hash = ?, password_hash = ?, password_salt = ? WHERE registration_number = ?";
            try (Connection connection = DriverManager.getConnection(DATABASE_URL);
                 PreparedStatement updatePs = connection.prepareStatement(updateSql)) {
                updatePs.setString(1, newDobHash);
                updatePs.setString(2, newPasswordHash);
                updatePs.setString(3, newSalt);
                updatePs.setString(4, registrationNumber.trim());
                return updatePs.executeUpdate() == 1;
            }
        }

        private List<Item> loadItems() throws SQLException {
            List<Item> loadedItems = new ArrayList<>();
            String sql = "SELECT id, status, item_name, category, location, date_time, "
                    + "appearance, condition, registration_id, reporter, contact "
                    + "FROM item_reports ORDER BY id";
            try (Connection connection = DriverManager.getConnection(DATABASE_URL);
                 Statement statement = connection.createStatement();
                 ResultSet results = statement.executeQuery(sql)) {
                while (results.next()) {
                    loadedItems.add(new Item(
                            results.getInt("id"),
                            results.getString("status"),
                            results.getString("item_name"),
                            results.getString("category"),
                            results.getString("location"),
                            results.getString("date_time"),
                            results.getString("appearance"),
                            results.getString("condition"),
                            results.getString("registration_id"),
                            results.getString("reporter"),
                            results.getString("contact")));
                }
            }
            return loadedItems;
        }

        private Item saveItem(Item item) throws SQLException {
            String insertSql = "INSERT INTO item_reports "
                    + "(status, item_name, category, location, date_time, appearance, "
                    + "condition, registration_id, reporter, contact) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            try (Connection connection = DriverManager.getConnection(DATABASE_URL);
                 PreparedStatement insert = connection.prepareStatement(insertSql);
                 Statement idQuery = connection.createStatement()) {
                insert.setString(1, item.status);
                insert.setString(2, item.name);
                insert.setString(3, item.category);
                insert.setString(4, item.location);
                insert.setString(5, item.dateTime);
                insert.setString(6, item.appearance);
                insert.setString(7, item.condition);
                insert.setString(8, item.registrationId);
                insert.setString(9, item.reporter);
                insert.setString(10, item.contact);
                insert.executeUpdate();

                try (ResultSet result = idQuery.executeQuery("SELECT last_insert_rowid()")) {
                    if (!result.next()) {
                        throw new SQLException("The database did not return a report ID.");
                    }
                    return new Item(result.getInt(1), item.status, item.name, item.category,
                            item.location, item.dateTime, item.appearance, item.condition,
                            item.registrationId, item.reporter, item.contact);
                }
            }
        }
    }

    private static class Item {
        private final int id;
        private final String status;
        private final String name;
        private final String category;
        private final String location;
        private final String dateTime;
        private final String appearance;
        private final String condition;
        private final String registrationId;
        private final String reporter;
        private final String contact;

        private Item(int id, String status, String name, String category,
                     String location, String dateTime, String appearance, String condition,
                     String registrationId, String reporter, String contact) {
            this.id = id;
            this.status = status;
            this.name = name;
            this.category = category;
            this.location = location;
            this.dateTime = dateTime;
            this.appearance = appearance;
            this.condition = condition;
            this.registrationId = registrationId;
            this.reporter = reporter;
            this.contact = contact;
        }

        @Override
        public String toString() {
            return "#" + id + "  " + status + " - " + name
                    + " (" + location + ", " + dateTime + ")";
        }
    }
}
