import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.Scrollable;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

public class Findagain {
    private static final Color NAVY = new Color(24, 43, 69);
    private static final Color TEAL = new Color(0, 132, 130);
    private static final Color BACKGROUND = new Color(245, 248, 250);
    private static final Color TEXT = new Color(42, 55, 70);
    private static final Color ERROR_BG = new Color(253, 237, 237);
    private static final Color ERROR_BORDER = new Color(217, 83, 79);
    private static final Color ERROR_TEXT = new Color(169, 68, 66);
    private static final Color SUCCESS_BG = new Color(230, 247, 238);
    private static final Color SUCCESS_TEXT = new Color(30, 126, 70);
    private static final Color LOST_ACCENT = new Color(205, 132, 40);
    private static final Color LOST_BG = new Color(255, 246, 231);
    private static final Color FOUND_BG = new Color(229, 247, 244);
    private static final Color FINDER_BG = new Color(233, 239, 247);
    private static final Color PHOTO_PLACEHOLDER_BG = new Color(242, 245, 248);
    private static final Color BORDER_LIGHT = new Color(220, 228, 235);
    private static final String PHOTOS_DIR = "data/photos";

    private static final Pattern REGISTRATION_PATTERN = Pattern.compile("^AP\\d{11}$");
    private static final Pattern DOB_PASSWORD_PATTERN = Pattern.compile("^\\d{8}$");

    private static final List<Item> items = new ArrayList<>();
    private static ItemDatabase database;

    private final JFrame frame = new JFrame("SRM AP Lost & Found");
    private final CardLayout rootLayout = new CardLayout();
    private final JPanel rootPanel = new JPanel(rootLayout);
    private final CardLayout cardLayout = new CardLayout();
    private final JPanel content = new JPanel(cardLayout);
    private final DefaultTableModel tableModel = new DefaultTableModel(
            new String[]{"ID", "Status", "Item", "Category", "Campus location",
                "Date / time", "Appearance", "Condition", "Registration ID", "Reporter", "Contact",
                "Item Photo", "Person Photo"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JComboBox<Item> itemSelector = new JComboBox<>();
    private final ScrollablePanel matchResultsPanel = new ScrollablePanel();
    private JScrollPane matchResultsScroll;
    private JCheckBox showPhotosCheck;
    private boolean matchesSearched = false;
    private boolean updatingItemSelector = false;
    private final JLabel lostCount = new JLabel("0");
    private final JLabel foundCount = new JLabel("0");

    // Login UI state
    private JTextField loginRegField;
    private JPasswordField loginPasswordField;
    private JCheckBox showPasswordCheck;
    private JLabel loginFeedbackLabel;
    private JButton loginButton;
    private char defaultPasswordEchoChar;

    // Session state
    private UserSession currentSession;
    private JLabel sessionUserLabel;
    private final LoginRateLimiter rateLimiter = new LoginRateLimiter(5, 30_000L);

    // Report page state
    private JLabel reportHeading;
    private JLabel reportSubtitle;
    private JLabel locationLabel;
    private JLabel dateTimeLabel;
    private JTextField nameField;
    private JComboBox<String> typeField;
    private JTextField otherTypeField;
    private JPanel otherTypeRow;
    private JTextField locationField;
    private JTextField dateTimeField;
    private JTextArea appearanceArea;
    private JTextField registrationIdField;
    private JPanel conditionRow;
    private JComboBox<String> conditionField;
    private JTextField reporterField;
    private JTextField contactField;
    private File selectedReportPhotoFile;
    private JLabel reportPhotoLabel;
    private JLabel reportPhotoPreviewLabel;
    private JLabel reportPhotoFileLabel;
    private JButton clearReportPhotoButton;
    private File selectedFinderPhotoFile;
    private JPanel finderPhotoRow;
    private JLabel finderPhotoLabel;
    private JLabel finderPhotoPreviewLabel;
    private JLabel finderPhotoFileLabel;
    private JButton clearFinderPhotoButton;
    private String reportStatus = "LOST";

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                database = new ItemDatabase();
                Findagain app = new Findagain();
                items.clear();
                items.addAll(database.loadItems());
                app.refreshDashboard();
                app.refreshReports();
                app.refreshItemSelector();
                app.show();
            } catch (SQLException exception) {
                String message = "Could not open the local reports database:\n"
                        + exception.getMessage();
                if (exception.getMessage() != null
                        && exception.getMessage().contains("No suitable driver")) {
                    message += "\n\nThe SQLite JDBC driver is missing. On Windows, start the app "
                            + "with run.bat, or use 'mvn compile exec:java'. "
                            + "Running only 'java Findagain' does not load the database driver.";
                }
                JOptionPane.showMessageDialog(null,
                        message,
                        "Database error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void show() {
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(920, 640));
        frame.setSize(1120, 720);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        rootPanel.add(createLoginView(), "login");
        rootPanel.add(createAuthenticatedAppView(), "app");

        frame.add(rootPanel, BorderLayout.CENTER);
        rootLayout.show(rootPanel, "login");
        frame.setVisible(true);
        if (loginRegField != null) {
            loginRegField.requestFocusInWindow();
        }
    }

    private JPanel createAuthenticatedAppView() {
        JPanel appShell = new JPanel(new BorderLayout());
        appShell.add(createHeader(), BorderLayout.NORTH);
        appShell.add(createSidebar(), BorderLayout.WEST);

        content.setBackground(BACKGROUND);
        content.add(createDashboard(), "dashboard");
        content.add(createReportPage(), "report");
        content.add(createReportsPage(), "reports");
        content.add(createMatchesPage(), "matches");
        appShell.add(content, BorderLayout.CENTER);
        return appShell;
    }

    private JPanel createLoginView() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setBackground(BACKGROUND);

        // Top branding bar matching existing header
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(Color.WHITE);
        topBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(225, 231, 236)),
                BorderFactory.createEmptyBorder(18, 28, 18, 28)));

        JLabel brandTitle = new JLabel("SRM AP  |  CAMPUS LOST & FOUND");
        brandTitle.setFont(new Font("SansSerif", Font.BOLD, 19));
        brandTitle.setForeground(NAVY);
        JLabel brandSubtitle = new JLabel("Student & Campus Community Authentication Portal");
        brandSubtitle.setFont(new Font("SansSerif", Font.PLAIN, 13));
        brandSubtitle.setForeground(new Color(105, 118, 130));

        JPanel brandBox = new JPanel();
        brandBox.setOpaque(false);
        brandBox.setLayout(new BoxLayout(brandBox, BoxLayout.Y_AXIS));
        brandBox.add(brandTitle);
        brandBox.add(Box.createVerticalStrut(4));
        brandBox.add(brandSubtitle);
        topBar.add(brandBox, BorderLayout.WEST);
        outer.add(topBar, BorderLayout.NORTH);

        // Centered responsive card container
        JPanel centerCanvas = new JPanel(new GridBagLayout());
        centerCanvas.setBackground(BACKGROUND);
        centerCanvas.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));

        JPanel loginCard = new JPanel();
        loginCard.setLayout(new BoxLayout(loginCard, BoxLayout.Y_AXIS));
        loginCard.setBackground(Color.WHITE);
        loginCard.setPreferredSize(new Dimension(460, 480));
        loginCard.setMaximumSize(new Dimension(500, 580));
        loginCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(4, 0, 0, 0, TEAL),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(222, 229, 235)),
                        BorderFactory.createEmptyBorder(28, 32, 28, 32))));

        JLabel badge = new JLabel("STUDENT LOGIN");
        badge.setFont(new Font("SansSerif", Font.BOLD, 11));
        badge.setForeground(TEAL);
        badge.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginCard.add(badge);
        loginCard.add(Box.createVerticalStrut(6));

        JLabel heading = new JLabel("Sign in to your account");
        heading.setFont(new Font("SansSerif", Font.BOLD, 24));
        heading.setForeground(NAVY);
        heading.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginCard.add(heading);
        loginCard.add(Box.createVerticalStrut(6));

        JLabel subtitle = new JLabel(
                "<html>Use your SRM AP Registration Number (<b>AP</b> + 11 digits) and your Date of Birth (<b>DDMMYYYY</b>) as your initial password.</html>");
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 13));
        subtitle.setForeground(new Color(95, 108, 120));
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginCard.add(subtitle);
        loginCard.add(Box.createVerticalStrut(18));

        loginFeedbackLabel = new JLabel();
        loginFeedbackLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        loginFeedbackLabel.setOpaque(true);
        loginFeedbackLabel.setVisible(false);
        loginFeedbackLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginFeedbackLabel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 56));
        loginCard.add(loginFeedbackLabel);
        loginCard.add(Box.createVerticalStrut(10));

        // Registration Number Field
        JLabel regLabel = fieldLabel("Registration Number *");
        regLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginCard.add(regLabel);
        loginCard.add(Box.createVerticalStrut(6));

        loginRegField = createTextField("Format: AP followed by 11 digits (e.g. AP12345678901)");
        loginRegField.setName("loginRegistrationField");
        loginRegField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(204, 214, 224)),
                BorderFactory.createEmptyBorder(8, 11, 8, 11)));
        loginRegField.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginRegField.addActionListener(event -> handleLogin());
        loginCard.add(loginRegField);
        loginCard.add(Box.createVerticalStrut(16));

        // Password Field
        JLabel passLabel = fieldLabel("Password (Initial: DOB in DDMMYYYY) *");
        passLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginCard.add(passLabel);
        loginCard.add(Box.createVerticalStrut(6));

        loginPasswordField = new JPasswordField();
        loginPasswordField.setName("loginPasswordField");
        loginPasswordField.setFont(new Font("SansSerif", Font.PLAIN, 14));
        loginPasswordField.setToolTipText("Enter your Date of Birth in DDMMYYYY format");
        loginPasswordField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        loginPasswordField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(204, 214, 224)),
                BorderFactory.createEmptyBorder(8, 11, 8, 11)));
        loginPasswordField.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginPasswordField.addActionListener(event -> handleLogin());
        defaultPasswordEchoChar = loginPasswordField.getEchoChar();
        loginCard.add(loginPasswordField);
        loginCard.add(Box.createVerticalStrut(10));

        // Show / Hide Password + Forgot Password Row
        JPanel optionsRow = new JPanel(new BorderLayout());
        optionsRow.setOpaque(false);
        optionsRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        optionsRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));

        showPasswordCheck = new JCheckBox("Show Password");
        showPasswordCheck.setName("showPasswordCheck");
        showPasswordCheck.setOpaque(false);
        showPasswordCheck.setFont(new Font("SansSerif", Font.PLAIN, 12));
        showPasswordCheck.setForeground(TEXT);
        showPasswordCheck.setFocusPainted(false);
        showPasswordCheck.addActionListener(event -> {
            if (showPasswordCheck.isSelected()) {
                loginPasswordField.setEchoChar((char) 0);
            } else {
                loginPasswordField.setEchoChar(defaultPasswordEchoChar);
            }
        });
        optionsRow.add(showPasswordCheck, BorderLayout.WEST);

        JButton forgotPasswordBtn = linkButton("Forgot Password?");
        forgotPasswordBtn.setName("forgotPasswordButton");
        forgotPasswordBtn.addActionListener(event -> openForgotPasswordDialog());
        optionsRow.add(forgotPasswordBtn, BorderLayout.EAST);

        loginCard.add(optionsRow);
        loginCard.add(Box.createVerticalStrut(16));

        // Login Button
        loginButton = primaryButton("Login to Campus Portal");
        loginButton.setName("loginSubmitButton");
        loginButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        loginButton.setHorizontalAlignment(SwingConstants.CENTER);
        loginButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        loginButton.addActionListener(event -> handleLogin());
        loginCard.add(loginButton);

        loginCard.add(Box.createVerticalStrut(16));

        // First-time registration row
        JPanel registerRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        registerRow.setOpaque(false);
        registerRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        registerRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        JLabel newStudentLabel = new JLabel("First time logging in?  ");
        newStudentLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        newStudentLabel.setForeground(new Color(95, 108, 120));
        JButton registerStudentBtn = linkButton("Register Student Account");
        registerStudentBtn.setName("registerStudentButton");
        registerStudentBtn.addActionListener(event -> openStudentRegistrationDialog());
        registerRow.add(newStudentLabel);
        registerRow.add(registerStudentBtn);
        loginCard.add(registerRow);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.anchor = GridBagConstraints.CENTER;
        centerCanvas.add(loginCard, gbc);

        JScrollPane scrollPane = new JScrollPane(centerCanvas);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        outer.add(scrollPane, BorderLayout.CENTER);

        return outer;
    }

    private JButton linkButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 12));
        button.setForeground(TEAL);
        button.setContentAreaFilled(false);
        button.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return button;
    }

    private void showLoginFeedback(String message, boolean isError) {
        if (loginFeedbackLabel == null) {
            return;
        }
        loginFeedbackLabel.setText("<html>" + escapeHtml(message) + "</html>");
        loginFeedbackLabel.setBackground(isError ? ERROR_BG : SUCCESS_BG);
        loginFeedbackLabel.setForeground(isError ? ERROR_TEXT : SUCCESS_TEXT);
        loginFeedbackLabel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(isError ? ERROR_BORDER : SUCCESS_TEXT),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)));
        loginFeedbackLabel.setVisible(true);
        loginFeedbackLabel.revalidate();
        loginFeedbackLabel.repaint();
    }

    private void clearLoginFeedback() {
        if (loginFeedbackLabel != null) {
            loginFeedbackLabel.setVisible(false);
            loginFeedbackLabel.setText("");
        }
    }

    static String validateRegistrationNumber(String input) {
        if (input == null || input.trim().isEmpty()) {
            return "Please enter your Registration Number.";
        }
        String trimmed = input.trim();
        if (!trimmed.startsWith("AP")) {
            return "Invalid Registration Number: It must start with uppercase 'AP' (e.g., AP12345678901).";
        }
        if (trimmed.length() != 13) {
            return "Invalid Registration Number: Total length must be exactly 13 characters ('AP' followed by 11 digits).";
        }
        String digitsPart = trimmed.substring(2);
        for (int i = 0; i < digitsPart.length(); i++) {
            if (!Character.isDigit(digitsPart.charAt(i))) {
                return "Invalid Registration Number: Only numeric digits (0-9) are allowed after 'AP'.";
            }
        }
        if (!REGISTRATION_PATTERN.matcher(trimmed).matches()) {
            return "Invalid Registration Number format. Expected AP followed by 11 digits.";
        }
        return null;
    }

    static String normalizeDobToCompact(String dobInput) {
        if (dobInput == null) {
            return null;
        }
        String cleaned = dobInput.trim().replace("-", "").replace("/", "").replace(".", "");
        if (!DOB_PASSWORD_PATTERN.matcher(cleaned).matches()) {
            return null;
        }
        int currentYear = LocalDate.now().getYear();
        try {
            int p1 = Integer.parseInt(cleaned.substring(0, 2));
            int p2 = Integer.parseInt(cleaned.substring(2, 4));
            int yEnd = Integer.parseInt(cleaned.substring(4, 8));

            // 1. Try DDMMYYYY (e.g. 15082005 or 28122006)
            if (yEnd >= 1900 && yEnd <= currentYear && p2 >= 1 && p2 <= 12 && p1 >= 1 && p1 <= 31) {
                try {
                    LocalDate parsed = LocalDate.of(yEnd, p2, p1);
                    if (!parsed.isAfter(LocalDate.now())) {
                        return String.format("%02d%02d%04d", p1, p2, yEnd);
                    }
                } catch (DateTimeException ignored) {
                }
            }

            // 2. Try MMDDYYYY (e.g. 12282006 -> month=12, day=28, year=2006)
            if (yEnd >= 1900 && yEnd <= currentYear && p1 >= 1 && p1 <= 12 && p2 >= 1 && p2 <= 31) {
                try {
                    LocalDate parsed = LocalDate.of(yEnd, p1, p2);
                    if (!parsed.isAfter(LocalDate.now())) {
                        return String.format("%02d%02d%04d", p2, p1, yEnd);
                    }
                } catch (DateTimeException ignored) {
                }
            }

            // 3. Try YYYYMMDD (e.g. 20061228 -> year=2006, month=12, day=28)
            int yStart = Integer.parseInt(cleaned.substring(0, 4));
            int mMid = Integer.parseInt(cleaned.substring(4, 6));
            int dEnd = Integer.parseInt(cleaned.substring(6, 8));
            if (yStart >= 1900 && yStart <= currentYear && mMid >= 1 && mMid <= 12 && dEnd >= 1 && dEnd <= 31) {
                try {
                    LocalDate parsed = LocalDate.of(yStart, mMid, dEnd);
                    if (!parsed.isAfter(LocalDate.now())) {
                        return String.format("%02d%02d%04d", dEnd, mMid, yStart);
                    }
                } catch (DateTimeException ignored) {
                }
            }
        } catch (NumberFormatException ex) {
            return null;
        }
        return null;
    }

    private void handleLogin() {
        clearLoginFeedback();
        String regNumber = loginRegField.getText() != null ? loginRegField.getText().trim() : "";
        char[] passwordChars = loginPasswordField.getPassword();
        String password = new String(passwordChars);
        java.util.Arrays.fill(passwordChars, '\0');

        // 1. Frontend format validation for Registration Number
        String regError = validateRegistrationNumber(regNumber);
        if (regError != null) {
            showLoginFeedback(regError, true);
            loginRegField.requestFocusInWindow();
            return;
        }

        // 2. Frontend validation for Password presence
        if (password.isEmpty()) {
            showLoginFeedback("Please enter your password (your Date of Birth in DDMMYYYY format).", true);
            loginPasswordField.requestFocusInWindow();
            return;
        }

        // 3. Rate limit check
        long remainingLockoutMs = rateLimiter.getRemainingLockoutMs(regNumber);
        if (remainingLockoutMs > 0) {
            long seconds = Math.max(1L, (remainingLockoutMs + 999L) / 1000L);
            showLoginFeedback("Too many failed login attempts. Please wait " + seconds + " second(s) before trying again.", true);
            return;
        }

        // 4. Backend / Database authentication
        try {
            AuthenticatedUser authUser = database.authenticateUser(regNumber, password);
            if (authUser == null) {
                rateLimiter.recordFailure(regNumber);
                showLoginFeedback("Invalid Registration Number or Password.", true);
                loginPasswordField.setText("");
                return;
            }

            // Successful login
            rateLimiter.reset(regNumber);
            currentSession = new UserSession(UUID.randomUUID().toString(), authUser, System.currentTimeMillis());
            loginPasswordField.setText("");
            showPasswordCheck.setSelected(false);
            loginPasswordField.setEchoChar(defaultPasswordEchoChar);
            clearLoginFeedback();

            updateSessionHeader();
            refreshDashboard();
            refreshReports();
            refreshItemSelector();
            cardLayout.show(content, "dashboard");
            rootLayout.show(rootPanel, "app");
        } catch (SQLException exception) {
            showLoginFeedback("Authentication service error. Please try again.", true);
        }
    }

    private void handleLogout() {
        currentSession = null;
        if (loginRegField != null) {
            loginRegField.setText("");
        }
        if (loginPasswordField != null) {
            loginPasswordField.setText("");
            loginPasswordField.setEchoChar(defaultPasswordEchoChar);
        }
        if (showPasswordCheck != null) {
            showPasswordCheck.setSelected(false);
        }
        clearLoginFeedback();
        clearReportForm();
        matchesSearched = false;
        rootLayout.show(rootPanel, "login");
        if (loginRegField != null) {
            loginRegField.requestFocusInWindow();
        }
    }

    private boolean ensureAuthenticated() {
        if (currentSession == null || currentSession.user == null) {
            rootLayout.show(rootPanel, "login");
            showLoginFeedback("Please log in with your Registration Number and Password to access this page.", true);
            return false;
        }
        return true;
    }

    private void updateSessionHeader() {
        if (sessionUserLabel != null && currentSession != null && currentSession.user != null) {
            sessionUserLabel.setText(currentSession.user.fullName + " (" + currentSession.user.registrationNumber + ")");
        }
    }

    private void openForgotPasswordDialog() {
        JDialog dialog = new JDialog(frame, "Reset / Forgot Password", true);
        dialog.setSize(450, 420);
        dialog.setLocationRelativeTo(frame);
        dialog.setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(22, 24, 22, 24));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("Reset Your Password");
        title.setFont(new Font("SansSerif", Font.BOLD, 19));
        title.setForeground(NAVY);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(title);
        panel.add(Box.createVerticalStrut(6));

        JLabel info = new JLabel(
                "<html>Verify your Registration Number and registered Date of Birth (<b>DD-MM-YYYY</b> or <b>DDMMYYYY</b>) to reset your password. Leave the new password blank to restore your DOB (DDMMYYYY) as your password.</html>");
        info.setFont(new Font("SansSerif", Font.PLAIN, 12));
        info.setForeground(new Color(95, 108, 120));
        info.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(info);
        panel.add(Box.createVerticalStrut(14));

        JTextField regField = createTextField("e.g. AP25110070127");
        if (loginRegField != null && !loginRegField.getText().trim().isEmpty()) {
            regField.setText(loginRegField.getText().trim());
        } else if (currentSession != null && currentSession.user != null) {
            regField.setText(currentSession.user.registrationNumber);
            regField.setEditable(false);
        }
        addFormField(panel, "Registration Number (AP + 11 digits) *", regField);

        JPasswordField dobField = new JPasswordField();
        dobField.setFont(new Font("SansSerif", Font.PLAIN, 14));
        dobField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        addFormField(panel, "Registered Date of Birth (DD-MM-YYYY or DDMMYYYY) *", dobField);

        JPasswordField newPassField = new JPasswordField();
        newPassField.setFont(new Font("SansSerif", Font.PLAIN, 14));
        newPassField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        addFormField(panel, "New Password (leave empty to reset to DOB DDMMYYYY)", newPassField);

        JCheckBox showChars = new JCheckBox("Show entered values");
        showChars.setOpaque(false);
        showChars.setFont(new Font("SansSerif", Font.PLAIN, 12));
        showChars.setAlignmentX(Component.LEFT_ALIGNMENT);
        char defaultEcho = dobField.getEchoChar();
        showChars.addActionListener(e -> {
            char echo = showChars.isSelected() ? (char) 0 : defaultEcho;
            dobField.setEchoChar(echo);
            newPassField.setEchoChar(echo);
        });
        panel.add(showChars);
        panel.add(Box.createVerticalStrut(14));

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttons.setOpaque(false);
        buttons.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton cancelBtn = new JButton("Cancel");
        cancelBtn.setFont(new Font("SansSerif", Font.PLAIN, 13));
        cancelBtn.addActionListener(e -> dialog.dispose());

        JButton resetBtn = primaryButton("Verify & Reset Password");
        resetBtn.addActionListener(e -> {
            String reg = regField.getText().trim();
            String regErr = validateRegistrationNumber(reg);
            if (regErr != null) {
                JOptionPane.showMessageDialog(dialog, regErr, "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String dobRaw = new String(dobField.getPassword()).trim();
            String dobCompact = normalizeDobToCompact(dobRaw);
            if (dobCompact == null) {
                JOptionPane.showMessageDialog(dialog,
                        "Please enter a valid calendar Date of Birth in DD-MM-YYYY or DDMMYYYY format.",
                        "Invalid Date of Birth", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String newPassword = new String(newPassField.getPassword()).trim();
            String targetPassword = newPassword.isEmpty() ? dobCompact : newPassword;
            if (targetPassword.length() < 6) {
                JOptionPane.showMessageDialog(dialog,
                        "Password must be at least 6 characters long.",
                        "Weak Password", JOptionPane.WARNING_MESSAGE);
                return;
            }
            try {
                boolean updated = database.resetPasswordWithDob(reg, dobCompact, targetPassword);
                if (!updated) {
                    JOptionPane.showMessageDialog(dialog,
                            "Could not verify Registration Number and Date of Birth.",
                            "Verification Failed", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                rateLimiter.reset(reg);
                JOptionPane.showMessageDialog(dialog,
                        newPassword.isEmpty()
                                ? "Your password has been reset to your Date of Birth (DDMMYYYY)."
                                : "Your password has been updated successfully.",
                        "Password Updated", JOptionPane.INFORMATION_MESSAGE);
                dialog.dispose();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(dialog,
                        "Database error while updating password.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        buttons.add(cancelBtn);
        buttons.add(resetBtn);
        panel.add(buttons);

        dialog.add(panel, BorderLayout.CENTER);
        dialog.setVisible(true);
    }

    private void openStudentRegistrationDialog() {
        JDialog dialog = new JDialog(frame, "First-Time Student Registration", true);
        dialog.setSize(470, 490);
        dialog.setLocationRelativeTo(frame);
        dialog.setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(22, 24, 22, 24));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("Register SRM AP Student Account");
        title.setFont(new Font("SansSerif", Font.BOLD, 19));
        title.setForeground(NAVY);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(title);
        panel.add(Box.createVerticalStrut(6));

        JLabel info = new JLabel(
                "<html>Your Date of Birth (<b>DDMMYYYY</b>) will be securely hashed and set as your initial login password.</html>");
        info.setFont(new Font("SansSerif", Font.PLAIN, 12));
        info.setForeground(new Color(95, 108, 120));
        info.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(info);
        panel.add(Box.createVerticalStrut(14));

        JTextField regField = createTextField("AP followed by 11 digits, e.g. AP12345678901");
        if (loginRegField != null && !loginRegField.getText().trim().isEmpty()) {
            regField.setText(loginRegField.getText().trim());
        }
        addFormField(panel, "Registration Number (AP + 11 digits) *", regField);

        JTextField fullNameField = createTextField("Your full name");
        addFormField(panel, "Full Name *", fullNameField);

        JTextField studentContactField = createTextField("Campus email or phone number");
        addFormField(panel, "Campus Email or Phone *", studentContactField);

        JTextField dobField = createTextField("DD-MM-YYYY (e.g. 15-08-2005)");
        addFormField(panel, "Date of Birth (DD-MM-YYYY) *", dobField);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        buttons.setOpaque(false);
        buttons.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton cancelBtn = new JButton("Cancel");
        cancelBtn.setFont(new Font("SansSerif", Font.PLAIN, 13));
        cancelBtn.addActionListener(e -> dialog.dispose());

        JButton registerBtn = primaryButton("Register Account");
        registerBtn.addActionListener(e -> {
            String reg = regField.getText().trim();
            String regErr = validateRegistrationNumber(reg);
            if (regErr != null) {
                JOptionPane.showMessageDialog(dialog, regErr, "Invalid Registration Number", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String fullName = fullNameField.getText().trim();
            String contactVal = studentContactField.getText().trim();
            String dobRaw = dobField.getText().trim();
            if (fullName.isEmpty() || contactVal.isEmpty() || dobRaw.isEmpty()) {
                JOptionPane.showMessageDialog(dialog,
                        "Please complete all required fields.",
                        "Missing Information", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String dobCompact = normalizeDobToCompact(dobRaw);
            if (dobCompact == null) {
                JOptionPane.showMessageDialog(dialog,
                        "Please enter a valid calendar Date of Birth in DD-MM-YYYY or DDMMYYYY format (e.g. 15-08-2005).",
                        "Invalid Date of Birth", JOptionPane.WARNING_MESSAGE);
                return;
            }
            try {
                if (database.userExists(reg)) {
                    JOptionPane.showMessageDialog(dialog,
                            "An account for Registration Number " + reg + " is already registered. Please sign in.",
                            "Already Registered", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                database.registerUser(reg, fullName, contactVal, dobCompact);
                if (loginRegField != null) {
                    loginRegField.setText(reg);
                }
                showLoginFeedback("Account registered for " + reg + ". Log in using your DOB in DDMMYYYY format.", false);
                dialog.dispose();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(dialog,
                        "Could not register account: " + ex.getMessage(),
                        "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        buttons.add(cancelBtn);
        buttons.add(registerBtn);
        panel.add(buttons);

        dialog.add(panel, BorderLayout.CENTER);
        dialog.setVisible(true);
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setBorder(BorderFactory.createEmptyBorder(18, 26, 18, 26));

        JLabel title = new JLabel("SRM AP  |  CAMPUS LOST & FOUND");
        title.setFont(new Font("SansSerif", Font.BOLD, 19));
        title.setForeground(NAVY);
        JLabel subtitle = new JLabel("A simple way to report and reunite with your belongings");
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 13));
        subtitle.setForeground(new Color(105, 118, 130));

        JPanel titles = new JPanel();
        titles.setOpaque(false);
        titles.setLayout(new BoxLayout(titles, BoxLayout.Y_AXIS));
        titles.add(title);
        titles.add(Box.createVerticalStrut(5));
        titles.add(subtitle);
        header.add(titles, BorderLayout.CENTER);

        // User session controls on the right
        JPanel sessionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 4));
        sessionPanel.setOpaque(false);

        sessionUserLabel = new JLabel("");
        sessionUserLabel.setFont(new Font("SansSerif", Font.BOLD, 13));
        sessionUserLabel.setForeground(NAVY);
        sessionPanel.add(sessionUserLabel);

        JButton changePassBtn = new JButton("Change Password");
        changePassBtn.setFont(new Font("SansSerif", Font.PLAIN, 12));
        changePassBtn.setForeground(NAVY);
        changePassBtn.setBackground(new Color(235, 241, 246));
        changePassBtn.setFocusPainted(false);
        changePassBtn.setBorder(BorderFactory.createEmptyBorder(7, 11, 7, 11));
        changePassBtn.addActionListener(e -> {
            if (ensureAuthenticated()) {
                openForgotPasswordDialog();
            }
        });
        sessionPanel.add(changePassBtn);

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setName("logoutButton");
        logoutBtn.setFont(new Font("SansSerif", Font.BOLD, 12));
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setBackground(NAVY);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBorder(BorderFactory.createEmptyBorder(7, 13, 7, 13));
        logoutBtn.addActionListener(e -> handleLogout());
        sessionPanel.add(logoutBtn);

        header.add(sessionPanel, BorderLayout.EAST);
        header.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(225, 231, 236)),
                BorderFactory.createEmptyBorder(18, 26, 18, 26)));
        return header;
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setBackground(NAVY);
        sidebar.setPreferredSize(new Dimension(205, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(22, 14, 18, 14));
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));

        JLabel menuLabel = new JLabel("MENU");
        menuLabel.setForeground(new Color(174, 193, 210));
        menuLabel.setFont(new Font("SansSerif", Font.BOLD, 11));
        menuLabel.setBorder(BorderFactory.createEmptyBorder(0, 12, 12, 0));
        menuLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        sidebar.add(menuLabel);
        sidebar.add(navButton("  Dashboard", "dashboard"));
        sidebar.add(navButton("  Report an item", "report"));
        sidebar.add(navButton("  All reports", "reports"));
        sidebar.add(navButton("  Find a match", "matches"));
        sidebar.add(Box.createVerticalGlue());

        JLabel campus = new JLabel("<html><b>SRM University-AP</b><br>Andhra Pradesh</html>");
        campus.setForeground(Color.WHITE);
        campus.setFont(new Font("SansSerif", Font.PLAIN, 12));
        campus.setBorder(BorderFactory.createEmptyBorder(12, 12, 0, 0));
        campus.setAlignmentX(Component.LEFT_ALIGNMENT);
        sidebar.add(campus);
        return sidebar;
    }

    private JButton navButton(String label, String card) {
        JButton button = new JButton(label);
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 43));
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        button.setForeground(Color.WHITE);
        button.setBackground(NAVY);
        button.setFont(new Font("SansSerif", Font.PLAIN, 14));
        button.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 8));
        button.setFocusPainted(false);
        button.addActionListener(event -> {
            if (!ensureAuthenticated()) {
                return;
            }
            if ("report".equals(card)) {
                openReportForm("LOST");
            } else if ("reports".equals(card)) {
                refreshReports();
            } else if ("matches".equals(card)) {
                refreshItemSelector();
                matchesSearched = false;
                renderMatchView();
            }
            cardLayout.show(content, card);
        });
        return button;
    }

    private JPanel createDashboard() {
        JPanel page = createPage();
        page.add(dashboardWelcome());

        JPanel stats = new JPanel(new GridLayout(1, 2, 16, 0));
        stats.setOpaque(false);
        stats.setMaximumSize(new Dimension(Integer.MAX_VALUE, 125));
        stats.add(statCard("LOST ITEM REPORTS", "Waiting to be reunited", lostCount,
                new Color(255, 246, 231), new Color(205, 132, 40)));
        stats.add(statCard("FOUND ITEM REPORTS", "Ready to find their owners", foundCount,
                new Color(229, 247, 244), TEAL));
        stats.setAlignmentX(Component.LEFT_ALIGNMENT);
        page.add(Box.createVerticalStrut(20));
        page.add(stats);

        JPanel actions = new JPanel(new GridLayout(1, 2, 16, 0));
        actions.setOpaque(false);
        actions.setMaximumSize(new Dimension(Integer.MAX_VALUE, 155));
        actions.setAlignmentX(Component.LEFT_ALIGNMENT);
        actions.add(actionCard("Lost something?", "Tell the campus community where and when you last saw it.",
                "Report a lost item",
                () -> openReportForm("LOST")));
        actions.add(actionCard("Found something?", "Share its location and help it get back to its owner.",
                "Report a found item",
                () -> openReportForm("FOUND")));
        page.add(Box.createVerticalStrut(18));
        page.add(actions);

        JLabel tip = new JLabel("<html><b>Quick tip</b>&nbsp;&nbsp; Include the item type, campus location, time, and appearance to improve matching.</html>");
        tip.setFont(new Font("SansSerif", Font.PLAIN, 13));
        tip.setForeground(NAVY);
        tip.setOpaque(true);
        tip.setBackground(new Color(233, 239, 247));
        tip.setBorder(BorderFactory.createEmptyBorder(13, 16, 13, 16));
        tip.setAlignmentX(Component.LEFT_ALIGNMENT);
        page.add(tip);
        return page;
    }

    private JPanel dashboardWelcome() {
        JPanel banner = new JPanel();
        banner.setLayout(new BoxLayout(banner, BoxLayout.Y_AXIS));
        banner.setBackground(NAVY);
        banner.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 5, 0, 0, TEAL),
                BorderFactory.createEmptyBorder(20, 22, 20, 22)));
        banner.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel eyebrow = new JLabel("SRM UNIVERSITY-AP  |  CAMPUS COMMUNITY");
        eyebrow.setFont(new Font("SansSerif", Font.BOLD, 11));
        eyebrow.setForeground(new Color(142, 213, 208));
        JLabel heading = new JLabel("Lost something? Found something?");
        heading.setFont(new Font("SansSerif", Font.BOLD, 24));
        heading.setForeground(Color.WHITE);
        JLabel subtitle = new JLabel("Report it here and help belongings find their way back to their owners.");
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 14));
        subtitle.setForeground(new Color(220, 229, 238));
        banner.add(eyebrow);
        banner.add(Box.createVerticalStrut(9));
        banner.add(heading);
        banner.add(Box.createVerticalStrut(6));
        banner.add(subtitle);
        return banner;
    }

    private JPanel statCard(String title, String subtitle, JLabel count, Color color, Color accent) {
        JPanel card = new JPanel();
        card.setBackground(color);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 4, 0, 0, accent),
                BorderFactory.createEmptyBorder(13, 17, 13, 17)));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        JLabel heading = new JLabel(title);
        heading.setFont(new Font("SansSerif", Font.BOLD, 12));
        heading.setForeground(NAVY);
        JLabel detail = new JLabel(subtitle);
        detail.setFont(new Font("SansSerif", Font.PLAIN, 12));
        detail.setForeground(new Color(90, 104, 117));
        count.setFont(new Font("SansSerif", Font.BOLD, 32));
        count.setForeground(NAVY);
        card.add(heading);
        card.add(Box.createVerticalStrut(4));
        card.add(detail);
        card.add(Box.createVerticalStrut(5));
        card.add(count);
        return card;
    }

    private JPanel actionCard(String title, String detail, String buttonText, Runnable action) {
        JPanel card = new JPanel();
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 4, 0, 0, TEAL),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(226, 232, 237)),
                        BorderFactory.createEmptyBorder(15, 17, 15, 17))));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        JLabel heading = new JLabel(title);
        heading.setFont(new Font("SansSerif", Font.BOLD, 17));
        heading.setForeground(NAVY);
        JLabel description = new JLabel(detail);
        description.setFont(new Font("SansSerif", Font.PLAIN, 13));
        description.setForeground(new Color(105, 118, 130));
        JButton button = primaryButton(buttonText);
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        button.addActionListener(event -> action.run());
        card.add(heading);
        card.add(Box.createVerticalStrut(5));
        card.add(description);
        card.add(Box.createVerticalStrut(13));
        card.add(button);
        return card;
    }

    private JPanel createReportPage() {
        JPanel page = createPage();
        JPanel title = pageTitle("", "");
        reportHeading = (JLabel) title.getComponent(0);
        reportSubtitle = (JLabel) title.getComponent(2);
        page.add(title);

        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setBackground(Color.WHITE);
        form.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(226, 232, 237)),
                BorderFactory.createEmptyBorder(20, 22, 20, 22)));
        form.setAlignmentX(Component.LEFT_ALIGNMENT);

        nameField = createTextField("e.g. Black backpack, student ID card");
        addFormField(form, "Item name *", nameField);

        typeField = new JComboBox<>(new String[]{
            "Select item type", "Electronics", "ID card", "Bag", "Clothing",
            "Keys", "Water bottle", "Books / stationery", "Accessories", "Other"
        });
        typeField.setFont(new Font("SansSerif", Font.PLAIN, 14));
        addFormField(form, "Type of item *", typeField);

        otherTypeField = createTextField("Specify the item type");
        otherTypeRow = createFormField("Specify item type *", otherTypeField);
        otherTypeRow.setVisible(false);
        form.add(otherTypeRow);
        typeField.addActionListener(event ->
                otherTypeRow.setVisible("Other".equals(typeField.getSelectedItem())));

        locationLabel = fieldLabel("Where on campus? *");
        locationField = createTextField("e.g. Library, first floor, near the east entrance");
        addFormField(form, locationLabel, locationField);

        dateTimeLabel = fieldLabel("When? *");
        dateTimeField = createTextField("Date and approximate time, e.g. 7 Nov, around 2:30 PM");
        addFormField(form, dateTimeLabel, dateTimeField);

        appearanceArea = createTextArea(
                "Color, size, brand, shape, pattern, or unique marks");
        addFormField(form, "Appearance / identifying features *", appearanceArea);

        form.add(createReportPhotoField());

        registrationIdField = createTextField("Your SRM AP registration number, e.g. AP12345678901");
        addFormField(form, "Your SRM AP Registration ID *", registrationIdField);

        conditionField = new JComboBox<>(new String[]{
            "Not specified", "Good", "Worn", "Damaged"
        });
        conditionField.setFont(new Font("SansSerif", Font.PLAIN, 14));
        conditionRow = createFormField(fieldLabel("Condition (if known)"), conditionField);
        form.add(conditionRow);

        reporterField = createTextField("Name of the person reporting this item");
        addFormField(form, "Your name *", reporterField);
        contactField = createTextField("Campus email or phone for arranging a handover");
        addFormField(form, "Campus email or phone *", contactField);

        finderPhotoRow = createFinderPhotoField();
        form.add(finderPhotoRow);

        JButton submit = primaryButton("Submit report");
        submit.setName("submitReportButton");
        submit.addActionListener(event -> submitReport());
        submit.setAlignmentX(Component.LEFT_ALIGNMENT);
        submit.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        form.add(Box.createVerticalStrut(8));
        form.add(submit);

        JLabel privacyNote = new JLabel(
                "Reports, registration IDs, and contact details are saved locally in the project database.");
        privacyNote.setFont(new Font("SansSerif", Font.PLAIN, 11));
        privacyNote.setForeground(new Color(105, 118, 130));
        privacyNote.setAlignmentX(Component.LEFT_ALIGNMENT);
        form.add(Box.createVerticalStrut(12));
        form.add(privacyNote);

        page.add(Box.createVerticalStrut(18));
        JScrollPane formScroll = new JScrollPane(form);
        formScroll.setBorder(BorderFactory.createEmptyBorder());
        formScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        page.add(formScroll);
        return page;
    }

    private JTextField createTextField(String hint) {
        JTextField field = new JTextField();
        field.setFont(new Font("SansSerif", Font.PLAIN, 14));
        field.setToolTipText(hint);
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        return field;
    }

    private JTextArea createTextArea(String hint) {
        JTextArea area = new JTextArea(3, 30);
        area.setFont(new Font("SansSerif", Font.PLAIN, 14));
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setToolTipText(hint);
        return area;
    }

    private void addFormField(JPanel form, String label, JComponent input) {
        addFormField(form, fieldLabel(label), input);
    }

    private void addFormField(JPanel form, JLabel label, JComponent input) {
        form.add(createFormField(label, input));
    }

    private JPanel createFormField(String label, JComponent input) {
        return createFormField(fieldLabel(label), input);
    }

    private JPanel createFormField(JLabel label, JComponent input) {
        JPanel row = new JPanel();
        row.setLayout(new BoxLayout(row, BoxLayout.Y_AXIS));
        row.setOpaque(false);
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        row.add(label);
        row.add(Box.createVerticalStrut(6));

        if (input instanceof JTextArea) {
            JScrollPane scrollPane = new JScrollPane(input);
            scrollPane.setPreferredSize(new Dimension(350, 78));
            scrollPane.setAlignmentX(Component.LEFT_ALIGNMENT);
            row.add(scrollPane);
        } else {
            input.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
            input.setAlignmentX(Component.LEFT_ALIGNMENT);
            row.add(input);
        }
        row.add(Box.createVerticalStrut(12));
        return row;
    }

    private JLabel fieldLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(TEXT);
        label.setFont(new Font("SansSerif", Font.BOLD, 13));
        return label;
    }

    private JPanel createReportPhotoField() {
        JPanel row = new JPanel();
        row.setLayout(new BoxLayout(row, BoxLayout.Y_AXIS));
        row.setOpaque(false);
        row.setAlignmentX(Component.LEFT_ALIGNMENT);

        reportPhotoLabel = fieldLabel("Item photo (optional)");
        reportPhotoLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        row.add(reportPhotoLabel);
        row.add(Box.createVerticalStrut(6));

        JPanel photoRow = new JPanel(new BorderLayout(14, 0));
        photoRow.setOpaque(false);
        photoRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        photoRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 102));

        reportPhotoPreviewLabel = new JLabel("No photo", SwingConstants.CENTER);
        reportPhotoPreviewLabel.setPreferredSize(new Dimension(128, 92));
        reportPhotoPreviewLabel.setMinimumSize(new Dimension(128, 92));
        reportPhotoPreviewLabel.setOpaque(true);
        reportPhotoPreviewLabel.setBackground(PHOTO_PLACEHOLDER_BG);
        reportPhotoPreviewLabel.setForeground(new Color(120, 132, 144));
        reportPhotoPreviewLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        reportPhotoPreviewLabel.setBorder(BorderFactory.createLineBorder(BORDER_LIGHT));
        photoRow.add(reportPhotoPreviewLabel, BorderLayout.WEST);

        JPanel controlsBox = new JPanel();
        controlsBox.setOpaque(false);
        controlsBox.setLayout(new BoxLayout(controlsBox, BoxLayout.Y_AXIS));

        reportPhotoFileLabel = new JLabel("Optional — take a photo directly with your camera or upload a photo to help verify matches visually.");
        reportPhotoFileLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        reportPhotoFileLabel.setForeground(new Color(95, 108, 120));
        reportPhotoFileLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        controlsBox.add(reportPhotoFileLabel);
        controlsBox.add(Box.createVerticalStrut(8));

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        btnRow.setOpaque(false);
        btnRow.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton takeBtn = cameraButton("Take Photo");
        takeBtn.addActionListener(event -> {
            File captured = capturePhotoFromCamera("Take Item Photo");
            if (captured == null) {
                return;
            }
            applySelectedReportPhoto(captured, "Captured from camera");
        });

        JButton chooseBtn = secondaryButton("Upload Photo");
        chooseBtn.addActionListener(event -> {
            File chosen = chooseImageFile(frame);
            if (chosen == null) {
                return;
            }
            applySelectedReportPhoto(chosen, "Selected: " + chosen.getName());
        });

        clearReportPhotoButton = secondaryButton("Remove");
        clearReportPhotoButton.setEnabled(false);
        clearReportPhotoButton.addActionListener(event -> resetReportPhotoSelection());

        btnRow.add(takeBtn);
        btnRow.add(chooseBtn);
        btnRow.add(clearReportPhotoButton);
        controlsBox.add(btnRow);

        photoRow.add(controlsBox, BorderLayout.CENTER);
        row.add(photoRow);
        row.add(Box.createVerticalStrut(12));
        return row;
    }

    private void applySelectedReportPhoto(File file, String statusText) {
        ImageIcon preview = loadScaledPhoto(file.getAbsolutePath(), 120, 84);
        if (preview == null) {
            JOptionPane.showMessageDialog(frame,
                    "Could not read the selected image file. Please choose a valid PNG, JPG, GIF, or BMP image.",
                    "Unsupported image", JOptionPane.WARNING_MESSAGE);
            return;
        }
        selectedReportPhotoFile = file;
        reportPhotoPreviewLabel.setText("");
        reportPhotoPreviewLabel.setIcon(preview);
        reportPhotoFileLabel.setText(statusText);
        clearReportPhotoButton.setEnabled(true);
    }

    private void resetReportPhotoSelection() {
        selectedReportPhotoFile = null;
        if (reportPhotoPreviewLabel != null) {
            reportPhotoPreviewLabel.setIcon(null);
            reportPhotoPreviewLabel.setText("No photo");
        }
        if (reportPhotoFileLabel != null) {
            boolean found = "FOUND".equals(reportStatus);
            reportPhotoFileLabel.setText(found
                    ? "Photo required — take a photo directly with your camera or upload a photo of the found item."
                    : "Optional — take a photo directly with your camera or upload a photo to help verify matches visually.");
        }
        if (clearReportPhotoButton != null) {
            clearReportPhotoButton.setEnabled(false);
        }
    }

    private JPanel createFinderPhotoField() {
        JPanel row = new JPanel();
        row.setLayout(new BoxLayout(row, BoxLayout.Y_AXIS));
        row.setOpaque(false);
        row.setAlignmentX(Component.LEFT_ALIGNMENT);

        finderPhotoLabel = fieldLabel("Photo of the person who found it *");
        finderPhotoLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        row.add(finderPhotoLabel);
        row.add(Box.createVerticalStrut(6));

        JPanel photoRow = new JPanel(new BorderLayout(14, 0));
        photoRow.setOpaque(false);
        photoRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        photoRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 102));

        finderPhotoPreviewLabel = new JLabel("No photo", SwingConstants.CENTER);
        finderPhotoPreviewLabel.setPreferredSize(new Dimension(128, 92));
        finderPhotoPreviewLabel.setMinimumSize(new Dimension(128, 92));
        finderPhotoPreviewLabel.setOpaque(true);
        finderPhotoPreviewLabel.setBackground(PHOTO_PLACEHOLDER_BG);
        finderPhotoPreviewLabel.setForeground(new Color(120, 132, 144));
        finderPhotoPreviewLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        finderPhotoPreviewLabel.setBorder(BorderFactory.createLineBorder(BORDER_LIGHT));
        photoRow.add(finderPhotoPreviewLabel, BorderLayout.WEST);

        JPanel controlsBox = new JPanel();
        controlsBox.setOpaque(false);
        controlsBox.setLayout(new BoxLayout(controlsBox, BoxLayout.Y_AXIS));

        finderPhotoFileLabel = new JLabel(
                "Photo required — take a photo directly with your camera or upload a photo of the person who found the item.");
        finderPhotoFileLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        finderPhotoFileLabel.setForeground(new Color(95, 108, 120));
        finderPhotoFileLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        controlsBox.add(finderPhotoFileLabel);
        controlsBox.add(Box.createVerticalStrut(8));

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        btnRow.setOpaque(false);
        btnRow.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton takeBtn = cameraButton("Take Photo");
        takeBtn.addActionListener(event -> {
            String role = "FOUND".equals(reportStatus) ? "Found" : "Lost";
            File captured = capturePhotoFromCamera("Take Photo of the Person Who " + role + " It");
            if (captured == null) {
                return;
            }
            applySelectedFinderPhoto(captured, "Captured from camera");
        });

        JButton chooseBtn = secondaryButton("Upload Person Photo");
        chooseBtn.addActionListener(event -> {
            String role = "FOUND".equals(reportStatus) ? "Found" : "Lost";
            File chosen = chooseImageFile(frame, "Select Photo of the Person Who " + role + " It");
            if (chosen == null) {
                return;
            }
            applySelectedFinderPhoto(chosen, "Selected: " + chosen.getName());
        });

        clearFinderPhotoButton = secondaryButton("Remove");
        clearFinderPhotoButton.setEnabled(false);
        clearFinderPhotoButton.addActionListener(event -> resetFinderPhotoSelection());

        btnRow.add(takeBtn);
        btnRow.add(chooseBtn);
        btnRow.add(clearFinderPhotoButton);
        controlsBox.add(btnRow);

        photoRow.add(controlsBox, BorderLayout.CENTER);
        row.add(photoRow);
        row.add(Box.createVerticalStrut(12));
        return row;
    }

    private void applySelectedFinderPhoto(File file, String statusText) {
        ImageIcon preview = loadScaledPhoto(file.getAbsolutePath(), 120, 84);
        if (preview == null) {
            JOptionPane.showMessageDialog(frame,
                    "Could not read the selected image file. Please choose a valid PNG, JPG, GIF, or BMP image.",
                    "Unsupported image", JOptionPane.WARNING_MESSAGE);
            return;
        }
        selectedFinderPhotoFile = file;
        finderPhotoPreviewLabel.setText("");
        finderPhotoPreviewLabel.setIcon(preview);
        finderPhotoFileLabel.setText(statusText);
        clearFinderPhotoButton.setEnabled(true);
    }

    private void resetFinderPhotoSelection() {
        selectedFinderPhotoFile = null;
        if (finderPhotoPreviewLabel != null) {
            finderPhotoPreviewLabel.setIcon(null);
            finderPhotoPreviewLabel.setText("No photo");
        }
        if (finderPhotoFileLabel != null) {
            boolean found = "FOUND".equals(reportStatus);
            finderPhotoFileLabel.setText(found
                    ? "Photo required — take a photo directly with your camera or upload a photo of the person who found the item."
                    : "Photo required — take a photo directly with your camera or upload a photo of the person who lost the item.");
        }
        if (clearFinderPhotoButton != null) {
            clearFinderPhotoButton.setEnabled(false);
        }
    }

    private JButton cameraButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(TEAL);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("SansSerif", Font.BOLD, 12));
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(TEAL),
                BorderFactory.createEmptyBorder(6, 12, 6, 12)));
        return button;
    }

    private JButton secondaryButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(235, 241, 246));
        button.setForeground(NAVY);
        button.setFont(new Font("SansSerif", Font.BOLD, 12));
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(204, 214, 224)),
                BorderFactory.createEmptyBorder(6, 12, 6, 12)));
        return button;
    }

    private JPanel createReportsPage() {
        JPanel page = createPage();
        page.add(pageTitle("All item reports", "Browse reports saved in the local database on this device."));
        JTable table = new JTable(tableModel);
        table.setRowHeight(28);
        table.setAutoCreateRowSorter(true);
        table.setFillsViewportHeight(true);
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));

        JPanel actionRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        actionRow.setOpaque(false);
        actionRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        actionRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        JButton viewPhotoBtn = secondaryButton("View Item Photo");
        viewPhotoBtn.addActionListener(event -> {
            Item selected = getSelectedTableItem(table);
            if (selected == null) {
                JOptionPane.showMessageDialog(frame, "Select a report row first.", "No selection", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            if (!selected.hasPhoto()) {
                JOptionPane.showMessageDialog(frame, "No item photo is attached to report #" + selected.id + " yet.", "No photo", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            openFullPhotoDialog(selected);
        });

        JButton attachPhotoBtn = secondaryButton("Add / Change Item Photo");
        attachPhotoBtn.setVisible(false);
        attachPhotoBtn.addActionListener(event -> {
            Item selected = getSelectedTableItem(table);
            if (selected == null) {
                JOptionPane.showMessageDialog(frame, "Select a report row first.", "No selection", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            attachPhotoToItem(selected, () -> {
                refreshReports();
                renderMatchView();
            });
        });

        JButton viewFinderPhotoBtn = secondaryButton("View Person Photo");
        viewFinderPhotoBtn.addActionListener(event -> {
            Item selected = getSelectedTableItem(table);
            if (selected == null) {
                JOptionPane.showMessageDialog(frame, "Select a report row first.", "No selection", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            if (!selected.hasFinderPhoto()) {
                JOptionPane.showMessageDialog(frame, "No person photo is attached to report #" + selected.id + " yet.", "No photo", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            openFullFinderPhotoDialog(selected);
        });

        JButton attachFinderPhotoBtn = secondaryButton("Add / Change Person Photo");
        attachFinderPhotoBtn.setVisible(false);
        attachFinderPhotoBtn.addActionListener(event -> {
            Item selected = getSelectedTableItem(table);
            if (selected == null) {
                JOptionPane.showMessageDialog(frame, "Select a report row first.", "No selection", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            attachFinderPhotoToItem(selected, () -> {
                refreshReports();
                renderMatchView();
            });
        });

        table.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting()) {
                Item selected = getSelectedTableItem(table);
                boolean isOwner = canCurrentUserEditPhotos(selected);
                attachPhotoBtn.setVisible(isOwner);
                attachFinderPhotoBtn.setVisible(isOwner);
                actionRow.revalidate();
                actionRow.repaint();
            }
        });

        actionRow.add(viewPhotoBtn);
        actionRow.add(attachPhotoBtn);
        actionRow.add(viewFinderPhotoBtn);
        actionRow.add(attachFinderPhotoBtn);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setAlignmentX(Component.LEFT_ALIGNMENT);
        page.add(Box.createVerticalStrut(14));
        page.add(actionRow);
        page.add(Box.createVerticalStrut(10));
        page.add(scrollPane);
        return page;
    }

    private Item getSelectedTableItem(JTable table) {
        int viewRow = table.getSelectedRow();
        if (viewRow < 0) {
            return null;
        }
        int modelRow = table.convertRowIndexToModel(viewRow);
        Object idVal = tableModel.getValueAt(modelRow, 0);
        if (!(idVal instanceof Integer)) {
            return null;
        }
        int itemId = (Integer) idVal;
        for (Item item : items) {
            if (item.id == itemId) {
                return item;
            }
        }
        return null;
    }

    private JPanel createMatchesPage() {
        JPanel page = createPage();
        page.add(pageTitle("Find a possible match",
                "Compare a report with reports of the opposite status and view Lost, Found, and Person photos."));

        JPanel controls = new JPanel(new BorderLayout(12, 0));
        controls.setOpaque(false);
        controls.setAlignmentX(Component.LEFT_ALIGNMENT);
        controls.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        itemSelector.setFont(new Font("SansSerif", Font.PLAIN, 14));
        itemSelector.addActionListener(event -> {
            if (!updatingItemSelector) {
                matchesSearched = false;
                renderMatchView();
            }
        });
        controls.add(itemSelector, BorderLayout.CENTER);
        JButton search = primaryButton("Find possible matches");
        search.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        search.addActionListener(event -> searchMatches());
        controls.add(search, BorderLayout.EAST);
        page.add(Box.createVerticalStrut(16));
        page.add(controls);

        JPanel optionsBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 4));
        optionsBar.setOpaque(false);
        optionsBar.setAlignmentX(Component.LEFT_ALIGNMENT);
        optionsBar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        showPhotosCheck = new JCheckBox("Show Lost, Found & Person photos", true);
        showPhotosCheck.setOpaque(false);
        showPhotosCheck.setFocusPainted(false);
        showPhotosCheck.setFont(new Font("SansSerif", Font.BOLD, 13));
        showPhotosCheck.setForeground(NAVY);
        showPhotosCheck.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        showPhotosCheck.addActionListener(event -> renderMatchView());
        optionsBar.add(showPhotosCheck);

        JLabel photoTip = new JLabel("   (Click any photo to view full size; only the person who submitted a report can change its photos)");
        photoTip.setFont(new Font("SansSerif", Font.PLAIN, 12));
        photoTip.setForeground(new Color(105, 118, 130));
        optionsBar.add(photoTip);

        page.add(Box.createVerticalStrut(8));
        page.add(optionsBar);

        matchResultsPanel.setLayout(new BoxLayout(matchResultsPanel, BoxLayout.Y_AXIS));
        matchResultsPanel.setBackground(BACKGROUND);
        matchResultsPanel.setBorder(BorderFactory.createEmptyBorder(4, 2, 12, 6));

        matchResultsScroll = new JScrollPane(matchResultsPanel);
        matchResultsScroll.setBorder(BorderFactory.createEmptyBorder());
        matchResultsScroll.getViewport().setBackground(BACKGROUND);
        matchResultsScroll.getVerticalScrollBar().setUnitIncrement(18);
        matchResultsScroll.setAlignmentX(Component.LEFT_ALIGNMENT);

        page.add(Box.createVerticalStrut(8));
        page.add(matchResultsScroll);
        return page;
    }

    private JPanel createPage() {
        JPanel page = new JPanel();
        page.setBackground(BACKGROUND);
        page.setBorder(BorderFactory.createEmptyBorder(26, 28, 26, 28));
        page.setLayout(new BoxLayout(page, BoxLayout.Y_AXIS));
        return page;
    }

    private JPanel pageTitle(String title, String subtitle) {
        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel heading = new JLabel(title);
        heading.setFont(new Font("SansSerif", Font.BOLD, 23));
        heading.setForeground(NAVY);
        JLabel detail = new JLabel(subtitle);
        detail.setFont(new Font("SansSerif", Font.PLAIN, 13));
        detail.setForeground(new Color(105, 118, 130));
        panel.add(heading);
        panel.add(Box.createVerticalStrut(6));
        panel.add(detail);
        return panel;
    }

    private JButton primaryButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(TEAL);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("SansSerif", Font.BOLD, 13));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        return button;
    }

    private void openReportForm(String status) {
        if (!ensureAuthenticated()) {
            return;
        }
        reportStatus = status;
        boolean found = "FOUND".equals(status);
        reportHeading.setText(found ? "Report a found item" : "Report a lost item");
        reportSubtitle.setText(found
                ? "Share where and when you found it so its owner can identify it."
                : "Tell us when and where you last saw it to help find a match.");
        locationLabel.setText(found ? "Where did you find it? *" : "Where did you last see it? *");
        dateTimeLabel.setText(found ? "When did you find it? *" : "When did you last see it? *");
        if (reportPhotoLabel != null) {
            reportPhotoLabel.setText(found ? "Item photo *" : "Item photo (optional)");
        }
        conditionRow.setVisible(found);
        if (finderPhotoLabel != null) {
            finderPhotoLabel.setText(found
                    ? "Photo of the person who found it *"
                    : "Photo of the person who lost it *");
        }
        if (finderPhotoRow != null) {
            finderPhotoRow.setVisible(true);
        }
        clearReportForm();
        content.revalidate();
        content.repaint();
        cardLayout.show(content, "report");
    }

    private void submitReport() {
        if (!ensureAuthenticated()) {
            return;
        }
        String name = nameField.getText().trim();
        String selectedType = (String) typeField.getSelectedItem();
        String category = "Other".equals(selectedType)
                ? otherTypeField.getText().trim() : selectedType;
        String location = locationField.getText().trim();
        String dateTime = dateTimeField.getText().trim();
        String appearance = appearanceArea.getText().trim();
        String registrationId = registrationIdField.getText().trim();
        String condition = "FOUND".equals(reportStatus)
                ? (String) conditionField.getSelectedItem() : "Not specified";
        String reporter = reporterField.getText().trim();
        String contact = contactField.getText().trim();
        if (name.isEmpty() || selectedType == null || "Select item type".equals(selectedType)
                || category.isEmpty() || location.isEmpty() || dateTime.isEmpty()
                || appearance.isEmpty() || registrationId.isEmpty()
                || reporter.isEmpty() || contact.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please complete all fields marked with *.",
                    "Missing information",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        String regValidationError = validateRegistrationNumber(registrationId);
        if (regValidationError != null) {
            JOptionPane.showMessageDialog(frame, regValidationError,
                    "Invalid Registration Number",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        if ("FOUND".equals(reportStatus) && selectedReportPhotoFile == null) {
            JOptionPane.showMessageDialog(frame,
                    "Please take a photo or upload a photo of the found item before submitting the report.",
                    "Photo required",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (selectedFinderPhotoFile == null) {
            String personRole = "FOUND".equals(reportStatus) ? "found" : "lost";
            JOptionPane.showMessageDialog(frame,
                    "Please take a photo or upload a photo of the person who " + personRole + " the item before submitting the report.",
                    "Person photo required",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        String savedPhotoPath = "";
        if (selectedReportPhotoFile != null) {
            try {
                savedPhotoPath = storeItemPhoto(selectedReportPhotoFile);
            } catch (IOException exception) {
                JOptionPane.showMessageDialog(frame,
                        "Could not save the selected photo: " + exception.getMessage(),
                        "Photo upload error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        String savedFinderPhotoPath = "";
        if (selectedFinderPhotoFile != null) {
            try {
                savedFinderPhotoPath = storeFinderPhoto(selectedFinderPhotoFile);
            } catch (IOException exception) {
                JOptionPane.showMessageDialog(frame,
                        "Could not save the selected person photo: " + exception.getMessage(),
                        "Photo upload error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        Item unsavedItem = new Item(0, reportStatus, name, category, location,
                dateTime, appearance, condition, registrationId, reporter, contact,
                savedPhotoPath, savedFinderPhotoPath);
        Item item;
        try {
            item = database.saveItem(unsavedItem);
        } catch (SQLException exception) {
            JOptionPane.showMessageDialog(frame,
                    "The report could not be saved. Please try again.\n" + exception.getMessage(),
                    "Database error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        items.add(item);
        clearReportForm();
        refreshDashboard();
        refreshReports();
        refreshItemSelector();

        List<Item> matches = findMatches(item);
        String message = "Your " + reportStatus.toLowerCase() + " report was submitted (ID " + item.id + ").";
        if (!matches.isEmpty()) {
            message += "\n\nPossible match(es) found: " + matches.size()
                    + ". Open Find a match to review them.";
        }
        JOptionPane.showMessageDialog(frame, message, "Report submitted", JOptionPane.INFORMATION_MESSAGE);
        cardLayout.show(content, "dashboard");
    }

    private void clearReportForm() {
        nameField.setText("");
        typeField.setSelectedIndex(0);
        otherTypeField.setText("");
        locationField.setText("");
        dateTimeField.setText("");
        appearanceArea.setText("");
        conditionField.setSelectedIndex(0);
        resetReportPhotoSelection();
        resetFinderPhotoSelection();
        if (currentSession != null && currentSession.user != null) {
            registrationIdField.setText(currentSession.user.registrationNumber);
            reporterField.setText(currentSession.user.fullName);
            contactField.setText(currentSession.user.contact);
        } else {
            registrationIdField.setText("");
            reporterField.setText("");
            contactField.setText("");
        }
    }

    private void refreshDashboard() {
        int lost = 0;
        int found = 0;
        for (Item item : items) {
            if ("LOST".equals(item.status)) {
                lost++;
            } else {
                found++;
            }
        }
        lostCount.setText(String.valueOf(lost));
        foundCount.setText(String.valueOf(found));
    }

    private void refreshReports() {
        tableModel.setRowCount(0);
        for (Item item : items) {
            tableModel.addRow(new Object[]{item.id, item.status, item.name,
                    item.category, item.location, item.dateTime, item.appearance, item.condition,
                    item.registrationId, item.reporter, item.contact,
                    item.hasPhoto() ? "Attached" : "None",
                    item.hasFinderPhoto() ? "Attached" : "None"});
        }
    }

    private void refreshItemSelector() {
        Item previouslySelected = (Item) itemSelector.getSelectedItem();
        Integer previousId = previouslySelected != null ? previouslySelected.id : null;
        updatingItemSelector = true;
        try {
            itemSelector.removeAllItems();
            Item toRestore = null;
            for (Item item : items) {
                itemSelector.addItem(item);
                if (previousId != null && item.id == previousId) {
                    toRestore = item;
                }
            }
            if (toRestore != null) {
                itemSelector.setSelectedItem(toRestore);
            }
        } finally {
            updatingItemSelector = false;
        }
    }

    private void searchMatches() {
        if (!ensureAuthenticated()) {
            return;
        }
        matchesSearched = true;
        renderMatchView();
    }

    private void renderMatchView() {
        matchResultsPanel.removeAll();
        boolean showPhotos = showPhotosCheck == null || showPhotosCheck.isSelected();
        Item selected = (Item) itemSelector.getSelectedItem();

        if (selected == null) {
            matchResultsPanel.add(createInfoCard(
                    "No reports available",
                    "Submit a lost or found report first to search for matches and compare photos."));
            refreshMatchScroll();
            return;
        }

        // Always show the selected report card with its photo & quick attach option
        matchResultsPanel.add(createSelectedItemCard(selected, showPhotos));
        matchResultsPanel.add(Box.createVerticalStrut(14));

        if (!matchesSearched) {
            matchResultsPanel.add(createInfoCard(
                    "Ready to compare",
                    "Click 'Find possible matches' above to compare this report against opposite-status reports and view Lost & Found item photos side by side."));
            refreshMatchScroll();
            return;
        }

        List<Item> matches = findMatches(selected);
        if (matches.isEmpty()) {
            matchResultsPanel.add(createInfoCard(
                    "No possible matches found",
                    "No opposite-status reports currently match " + selected + ". Matches are suggestions only; check identifying details before claiming an item."));
            refreshMatchScroll();
            return;
        }

        JLabel sectionHeading = new JLabel(
                "Possible Matches (" + matches.size() + ") — Lost & Found Comparison");
        sectionHeading.setFont(new Font("SansSerif", Font.BOLD, 16));
        sectionHeading.setForeground(NAVY);
        sectionHeading.setAlignmentX(Component.LEFT_ALIGNMENT);
        matchResultsPanel.add(sectionHeading);
        matchResultsPanel.add(Box.createVerticalStrut(10));

        int matchIndex = 1;
        for (Item match : matches) {
            int score = getMatchScore(selected, match);
            matchResultsPanel.add(createMatchComparisonCard(matchIndex++, selected, match, score, showPhotos));
            matchResultsPanel.add(Box.createVerticalStrut(14));
        }

        JLabel disclaimer = new JLabel(
                "<html><i>Matches are suggestions only. Compare the item photos, verify the finder's photo, and confirm ownership in person before handing over an item.</i></html>");
        disclaimer.setFont(new Font("SansSerif", Font.PLAIN, 12));
        disclaimer.setForeground(new Color(105, 118, 130));
        disclaimer.setAlignmentX(Component.LEFT_ALIGNMENT);
        matchResultsPanel.add(disclaimer);

        refreshMatchScroll();
    }

    private void refreshMatchScroll() {
        matchResultsPanel.revalidate();
        matchResultsPanel.repaint();
        if (matchResultsScroll != null) {
            SwingUtilities.invokeLater(() -> matchResultsScroll.getVerticalScrollBar().setValue(0));
        }
    }

    private JPanel createInfoCard(String headingText, String messageText) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_LIGHT),
                BorderFactory.createEmptyBorder(16, 18, 16, 18)));

        JLabel heading = new JLabel(headingText);
        heading.setFont(new Font("SansSerif", Font.BOLD, 15));
        heading.setForeground(NAVY);
        heading.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel body = new JLabel("<html><body style='width: 640px'>" + escapeHtml(messageText) + "</body></html>");
        body.setFont(new Font("SansSerif", Font.PLAIN, 13));
        body.setForeground(TEXT);
        body.setAlignmentX(Component.LEFT_ALIGNMENT);

        card.add(heading);
        card.add(Box.createVerticalStrut(6));
        card.add(body);
        return card;
    }

    private JPanel createSelectedItemCard(Item item, boolean showPhotos) {
        boolean isLost = "LOST".equals(item.status);
        Color accent = isLost ? LOST_ACCENT : TEAL;
        Color badgeBg = isLost ? LOST_BG : FOUND_BG;

        JPanel card = new JPanel(new BorderLayout(16, 10));
        card.setBackground(Color.WHITE);
        card.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 5, 0, 0, accent),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER_LIGHT),
                        BorderFactory.createEmptyBorder(14, 16, 14, 16))));

        // Top bar
        JPanel header = new JPanel(new BorderLayout(8, 0));
        header.setOpaque(false);
        JLabel badge = new JLabel("SELECTED " + item.status + " REPORT  #" + item.id);
        badge.setFont(new Font("SansSerif", Font.BOLD, 11));
        badge.setForeground(accent);
        badge.setOpaque(true);
        badge.setBackground(badgeBg);
        badge.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        header.add(badge, BorderLayout.WEST);

        JLabel title = new JLabel(item.name + "  (" + item.category + ")");
        title.setFont(new Font("SansSerif", Font.BOLD, 16));
        title.setForeground(NAVY);
        header.add(title, BorderLayout.CENTER);
        card.add(header, BorderLayout.NORTH);

        // Details
        String detailsHtml = "<html><body style='width: 460px'>"
                + "<b>Location:</b> " + escapeHtml(item.location)
                + " &nbsp;|&nbsp; <b>When:</b> " + escapeHtml(item.dateTime) + "<br>"
                + "<b>Appearance:</b> " + escapeHtml(item.appearance) + "<br>"
                + "<b>Condition:</b> " + escapeHtml(item.condition)
                + " &nbsp;|&nbsp; <b>Registration ID:</b> " + escapeHtml(item.registrationId) + "<br>"
                + "<b>Reporter:</b> " + escapeHtml(item.reporter) + " (" + escapeHtml(item.contact) + ")"
                + "</body></html>";
        JLabel detailsLabel = new JLabel(detailsHtml);
        detailsLabel.setFont(new Font("SansSerif", Font.PLAIN, 13));
        detailsLabel.setForeground(TEXT);
        detailsLabel.setVerticalAlignment(SwingConstants.TOP);
        card.add(detailsLabel, BorderLayout.CENTER);

        if (showPhotos) {
            JPanel photoTile = createPhotoTile(item, item.status + " ITEM PHOTO", 190, 135);
            card.add(photoTile, BorderLayout.EAST);
        }

        return card;
    }

    private JPanel createMatchComparisonCard(int matchNumber, Item selected, Item match,
                                             int score, boolean showPhotos) {
        Item lostItem = "LOST".equals(selected.status) ? selected : match;
        Item foundItem = "FOUND".equals(selected.status) ? selected : match;

        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(3, 0, 0, 0, TEAL),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER_LIGHT),
                        BorderFactory.createEmptyBorder(14, 16, 14, 16))));

        // Header row
        JPanel headerRow = new JPanel(new BorderLayout(10, 0));
        headerRow.setOpaque(false);
        headerRow.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel title = new JLabel("Match #" + matchNumber + "  —  "
                + match.status + " #" + match.id + ": " + match.name);
        title.setFont(new Font("SansSerif", Font.BOLD, 16));
        title.setForeground(NAVY);
        headerRow.add(title, BorderLayout.CENTER);

        String strengthText = score >= 4 ? "Strong Match" : (score == 3 ? "Good Match" : "Possible Match");
        JLabel scoreBadge = new JLabel(strengthText);
        scoreBadge.setFont(new Font("SansSerif", Font.BOLD, 11));
        scoreBadge.setOpaque(true);
        scoreBadge.setBackground(score >= 4 ? SUCCESS_BG : FOUND_BG);
        scoreBadge.setForeground(score >= 4 ? SUCCESS_TEXT : TEAL);
        scoreBadge.setBorder(BorderFactory.createEmptyBorder(4, 10, 4, 10));
        headerRow.add(scoreBadge, BorderLayout.EAST);

        card.add(headerRow);
        card.add(Box.createVerticalStrut(12));

        // Side-by-side Lost vs Found Item Photos + Side-by-side Person Who Lost vs Person Who Found Photos
        if (showPhotos) {
            JPanel photoPairPanel = new JPanel(new GridLayout(1, 2, 16, 0));
            photoPairPanel.setOpaque(false);
            photoPairPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

            photoPairPanel.add(createPhotoTile(
                    lostItem,
                    "LOST ITEM  #" + lostItem.id + " — " + lostItem.name,
                    260, 175));
            photoPairPanel.add(createPhotoTile(
                    foundItem,
                    "FOUND ITEM  #" + foundItem.id + " — " + foundItem.name,
                    260, 175));

            card.add(photoPairPanel);
            card.add(Box.createVerticalStrut(12));

            JPanel personPairPanel = new JPanel(new GridLayout(1, 2, 16, 0));
            personPairPanel.setOpaque(false);
            personPairPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

            personPairPanel.add(createFinderPhotoTile(lostItem, 260, 175));
            personPairPanel.add(createFinderPhotoTile(foundItem, 260, 175));

            card.add(personPairPanel);
            card.add(Box.createVerticalStrut(12));
        }

        // Matched item full details & both people's contact info
        JPanel detailsBox = new JPanel(new BorderLayout());
        detailsBox.setBackground(new Color(249, 251, 253));
        detailsBox.setAlignmentX(Component.LEFT_ALIGNMENT);
        detailsBox.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(232, 238, 243)),
                BorderFactory.createEmptyBorder(10, 12, 10, 12)));

        String matchDetailsHtml = "<html><body style='width: 640px'>"
                + "<b>Matched " + escapeHtml(match.status) + " Report Details (#" + match.id + ")</b><br>"
                + "<b>Type:</b> " + escapeHtml(match.category)
                + " &nbsp;|&nbsp; <b>Location:</b> " + escapeHtml(match.location)
                + " &nbsp;|&nbsp; <b>When:</b> " + escapeHtml(match.dateTime) + "<br>"
                + "<b>Appearance:</b> " + escapeHtml(match.appearance)
                + " &nbsp;|&nbsp; <b>Condition:</b> " + escapeHtml(match.condition) + "<br><br>"
                + "<b>Person Who Lost the Item (#" + lostItem.id + "):</b> "
                + escapeHtml(lostItem.reporter)
                + " (" + escapeHtml(lostItem.registrationId) + ") &nbsp;|&nbsp; "
                + escapeHtml(lostItem.contact) + "<br>"
                + "<b>Person Who Found the Item (#" + foundItem.id + "):</b> "
                + escapeHtml(foundItem.reporter)
                + " (" + escapeHtml(foundItem.registrationId) + ") &nbsp;|&nbsp; "
                + escapeHtml(foundItem.contact)
                + "</body></html>";
        JLabel details = new JLabel(matchDetailsHtml);
        details.setFont(new Font("SansSerif", Font.PLAIN, 13));
        details.setForeground(TEXT);
        details.setVerticalAlignment(SwingConstants.TOP);
        detailsBox.add(details, BorderLayout.CENTER);

        card.add(detailsBox);

        return card;
    }

    private boolean canCurrentUserEditPhotos(Item item) {
        return currentSession != null
                && currentSession.user != null
                && item != null
                && item.registrationId != null
                && currentSession.user.registrationNumber.equalsIgnoreCase(item.registrationId.trim());
    }

    private JPanel createFinderPhotoTile(Item item, int imgWidth, int imgHeight) {
        boolean isLost = "LOST".equals(item.status);
        boolean canEdit = canCurrentUserEditPhotos(item);
        String heading = isLost
                ? "PERSON WHO LOST IT  —  " + item.reporter
                : "PERSON WHO FOUND IT  —  " + item.reporter;
        Color accent = isLost ? LOST_ACCENT : NAVY;
        Color headerBg = isLost ? LOST_BG : FINDER_BG;

        JPanel tile = new JPanel(new BorderLayout(0, 6));
        tile.setBackground(Color.WHITE);
        tile.setBorder(BorderFactory.createLineBorder(BORDER_LIGHT));

        JLabel topLabel = new JLabel(heading);
        topLabel.setToolTipText((isLost ? "Owner: " : "Finder: ") + item.reporter + " (" + item.registrationId + ")");
        topLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
        topLabel.setForeground(NAVY);
        topLabel.setOpaque(true);
        topLabel.setBackground(headerBg);
        topLabel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 4, 1, 0, accent),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)));
        tile.add(topLabel, BorderLayout.NORTH);

        JLabel imageHolder = new JLabel("", SwingConstants.CENTER);
        imageHolder.setPreferredSize(new Dimension(imgWidth + 16, imgHeight + 14));
        imageHolder.setMinimumSize(new Dimension(imgWidth, imgHeight));
        imageHolder.setOpaque(true);
        imageHolder.setBackground(PHOTO_PLACEHOLDER_BG);

        ImageIcon icon = loadScaledPhoto(item.finderPhotoPath, imgWidth, imgHeight);
        if (icon != null) {
            imageHolder.setIcon(icon);
            imageHolder.setToolTipText("Click to view full-size photo of " + item.reporter);
            imageHolder.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            imageHolder.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    openFullFinderPhotoDialog(item);
                }
            });
        } else {
            String placeholder;
            if (canEdit) {
                placeholder = item.hasFinderPhoto()
                        ? "<html><center>Person photo file not found<br><span style='color:#6b7a8c;font-size:10px;'>Take or upload a new photo below</span></center></html>"
                        : "<html><center>No person photo uploaded<br><span style='color:#6b7a8c;font-size:10px;'>Click 'Take Photo' or 'Add Photo' below</span></center></html>";
            } else {
                placeholder = item.hasFinderPhoto()
                        ? "<html><center>Person photo unavailable</center></html>"
                        : "<html><center>No person photo uploaded</center></html>";
            }
            imageHolder.setText(placeholder);
            imageHolder.setFont(new Font("SansSerif", Font.PLAIN, 12));
            imageHolder.setForeground(new Color(120, 132, 144));
        }
        tile.add(imageHolder, BorderLayout.CENTER);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 4));
        footer.setBackground(Color.WHITE);

        if (canEdit) {
            JButton takeBtn = cameraButton("Take Photo");
            takeBtn.setFont(new Font("SansSerif", Font.BOLD, 11));
            takeBtn.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(TEAL),
                    BorderFactory.createEmptyBorder(4, 8, 4, 8)));
            takeBtn.addActionListener(event -> takeFinderPhotoForItem(item, () -> {
                refreshReports();
                renderMatchView();
            }));
            footer.add(takeBtn);

            JButton uploadBtn = secondaryButton(icon != null ? "Change" : "Add Photo");
            uploadBtn.setFont(new Font("SansSerif", Font.BOLD, 11));
            uploadBtn.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(204, 214, 224)),
                    BorderFactory.createEmptyBorder(4, 8, 4, 8)));
            uploadBtn.addActionListener(event -> attachFinderPhotoToItem(item, () -> {
                refreshReports();
                renderMatchView();
            }));
            footer.add(uploadBtn);
        }

        if (icon != null) {
            JButton zoomBtn = secondaryButton("Enlarge");
            zoomBtn.setFont(new Font("SansSerif", Font.PLAIN, 11));
            zoomBtn.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(204, 214, 224)),
                    BorderFactory.createEmptyBorder(4, 8, 4, 8)));
            zoomBtn.addActionListener(event -> openFullFinderPhotoDialog(item));
            footer.add(zoomBtn);
        }

        if (footer.getComponentCount() > 0) {
            tile.add(footer, BorderLayout.SOUTH);
        }
        return tile;
    }

    private JPanel createPhotoTile(Item item, String headingText, int imgWidth, int imgHeight) {
        boolean isLost = "LOST".equals(item.status);
        boolean canEdit = canCurrentUserEditPhotos(item);
        Color accent = isLost ? LOST_ACCENT : TEAL;
        Color headerBg = isLost ? LOST_BG : FOUND_BG;

        JPanel tile = new JPanel(new BorderLayout(0, 6));
        tile.setBackground(Color.WHITE);
        tile.setBorder(BorderFactory.createLineBorder(BORDER_LIGHT));

        JLabel topLabel = new JLabel(headingText);
        topLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
        topLabel.setForeground(NAVY);
        topLabel.setOpaque(true);
        topLabel.setBackground(headerBg);
        topLabel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 4, 1, 0, accent),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)));
        tile.add(topLabel, BorderLayout.NORTH);

        JLabel imageHolder = new JLabel("", SwingConstants.CENTER);
        imageHolder.setPreferredSize(new Dimension(imgWidth + 16, imgHeight + 14));
        imageHolder.setMinimumSize(new Dimension(imgWidth, imgHeight));
        imageHolder.setOpaque(true);
        imageHolder.setBackground(PHOTO_PLACEHOLDER_BG);

        ImageIcon icon = loadScaledPhoto(item.photoPath, imgWidth, imgHeight);
        if (icon != null) {
            imageHolder.setIcon(icon);
            imageHolder.setToolTipText("Click to view full-size photo");
            imageHolder.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            imageHolder.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    openFullPhotoDialog(item);
                }
            });
        } else {
            String placeholder;
            if (canEdit) {
                placeholder = item.hasPhoto()
                        ? "<html><center>Photo file not found<br><span style='color:#6b7a8c;font-size:10px;'>Take or upload a new photo below</span></center></html>"
                        : "<html><center>No photo uploaded<br><span style='color:#6b7a8c;font-size:10px;'>Click 'Take Photo' or 'Add Photo' below</span></center></html>";
            } else {
                placeholder = item.hasPhoto()
                        ? "<html><center>Photo unavailable</center></html>"
                        : "<html><center>No photo uploaded</center></html>";
            }
            imageHolder.setText(placeholder);
            imageHolder.setFont(new Font("SansSerif", Font.PLAIN, 12));
            imageHolder.setForeground(new Color(120, 132, 144));
        }
        tile.add(imageHolder, BorderLayout.CENTER);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 4));
        footer.setBackground(Color.WHITE);

        if (canEdit) {
            JButton takeBtn = cameraButton("Take Photo");
            takeBtn.setFont(new Font("SansSerif", Font.BOLD, 11));
            takeBtn.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(TEAL),
                    BorderFactory.createEmptyBorder(4, 8, 4, 8)));
            takeBtn.addActionListener(event -> takePhotoForItem(item, () -> {
                refreshReports();
                renderMatchView();
            }));
            footer.add(takeBtn);

            JButton uploadBtn = secondaryButton(icon != null ? "Change" : "Add Photo");
            uploadBtn.setFont(new Font("SansSerif", Font.BOLD, 11));
            uploadBtn.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(204, 214, 224)),
                    BorderFactory.createEmptyBorder(4, 8, 4, 8)));
            uploadBtn.addActionListener(event -> attachPhotoToItem(item, () -> {
                refreshReports();
                renderMatchView();
            }));
            footer.add(uploadBtn);
        }

        if (icon != null) {
            JButton zoomBtn = secondaryButton("Enlarge");
            zoomBtn.setFont(new Font("SansSerif", Font.PLAIN, 11));
            zoomBtn.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(204, 214, 224)),
                    BorderFactory.createEmptyBorder(4, 8, 4, 8)));
            zoomBtn.addActionListener(event -> openFullPhotoDialog(item));
            footer.add(zoomBtn);

            if (isLost && canEdit) {
                JButton removeBtn = secondaryButton("Remove");
                removeBtn.setFont(new Font("SansSerif", Font.PLAIN, 11));
                removeBtn.setForeground(ERROR_TEXT);
                removeBtn.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(228, 198, 198)),
                        BorderFactory.createEmptyBorder(4, 8, 4, 8)));
                removeBtn.addActionListener(event -> removePhotoFromItem(item, () -> {
                    refreshReports();
                    renderMatchView();
                }));
                footer.add(removeBtn);
            }
        }

        if (footer.getComponentCount() > 0) {
            tile.add(footer, BorderLayout.SOUTH);
        }
        return tile;
    }

    private File chooseImageFile(Component parent) {
        return chooseImageFile(parent, "Select Item Photo");
    }

    private File chooseImageFile(Component parent, String dialogTitle) {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle(dialogTitle);
        chooser.setAcceptAllFileFilterUsed(false);
        chooser.setFileFilter(new FileNameExtensionFilter(
                "Image Files (PNG, JPG, JPEG, GIF, BMP)", "png", "jpg", "jpeg", "gif", "bmp"));
        int result = chooser.showOpenDialog(parent);
        if (result == JFileChooser.APPROVE_OPTION) {
            return chooser.getSelectedFile();
        }
        return null;
    }

    private String storeItemPhoto(File sourceFile) throws IOException {
        return storePhoto(sourceFile, "item_");
    }

    private String storeFinderPhoto(File sourceFile) throws IOException {
        return storePhoto(sourceFile, "finder_");
    }

    private String storePhoto(File sourceFile, String prefix) throws IOException {
        if (sourceFile == null || !sourceFile.exists() || !sourceFile.isFile()) {
            throw new IOException("Selected photo file does not exist.");
        }
        BufferedImage verified = ImageIO.read(sourceFile);
        if (verified == null) {
            throw new IOException("Unsupported or unreadable image format.");
        }
        Path photosDir = Paths.get(PHOTOS_DIR);
        Files.createDirectories(photosDir);

        String originalName = sourceFile.getName();
        String extension = "png";
        int dotIndex = originalName.lastIndexOf('.');
        if (dotIndex >= 0 && dotIndex < originalName.length() - 1) {
            String candidate = originalName.substring(dotIndex + 1).toLowerCase(Locale.ENGLISH);
            if (candidate.equals("png") || candidate.equals("jpg") || candidate.equals("jpeg")
                    || candidate.equals("gif") || candidate.equals("bmp")) {
                extension = candidate;
            }
        }

        String fileName = prefix + UUID.randomUUID().toString().replace("-", "") + "." + extension;
        Path targetPath = photosDir.resolve(fileName);
        Files.copy(sourceFile.toPath(), targetPath, StandardCopyOption.REPLACE_EXISTING);
        return PHOTOS_DIR + "/" + fileName;
    }

    private ImageIcon loadScaledPhoto(String photoPath, int maxWidth, int maxHeight) {
        if (photoPath == null || photoPath.trim().isEmpty()) {
            return null;
        }
        File file = new File(photoPath);
        if (!file.exists() || !file.isFile()) {
            return null;
        }
        try {
            BufferedImage original = ImageIO.read(file);
            if (original == null || original.getWidth() <= 0 || original.getHeight() <= 0) {
                return null;
            }
            double widthRatio = (double) maxWidth / original.getWidth();
            double heightRatio = (double) maxHeight / original.getHeight();
            double scale = Math.min(widthRatio, heightRatio);
            int targetW = Math.max(1, (int) Math.round(original.getWidth() * scale));
            int targetH = Math.max(1, (int) Math.round(original.getHeight() * scale));

            BufferedImage scaled = new BufferedImage(targetW, targetH, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2 = scaled.createGraphics();
            try {
                g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.drawImage(original, 0, 0, targetW, targetH, null);
            } finally {
                g2.dispose();
            }
            return new ImageIcon(scaled);
        } catch (IOException ex) {
            return null;
        }
    }

    private boolean ensureCanEditPhotos(Item item) {
        if (!ensureAuthenticated() || item == null) {
            return false;
        }
        if (!canCurrentUserEditPhotos(item)) {
            JOptionPane.showMessageDialog(frame,
                    "Only the person who submitted report #" + item.id + " (" + item.registrationId + ") can add, change, or remove its photos.",
                    "Permission Denied", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    private void attachPhotoToItem(Item item, Runnable onUpdated) {
        if (!ensureCanEditPhotos(item)) {
            return;
        }
        File chosen = chooseImageFile(frame);
        if (chosen == null) {
            return;
        }
        saveItemPhotoFile(item, chosen, onUpdated);
    }

    private void takePhotoForItem(Item item, Runnable onUpdated) {
        if (!ensureCanEditPhotos(item)) {
            return;
        }
        File captured = capturePhotoFromCamera("Take " + item.status + " Item Photo — #" + item.id);
        if (captured == null) {
            return;
        }
        saveItemPhotoFile(item, captured, onUpdated);
    }

    private void saveItemPhotoFile(Item item, File photoFile, Runnable onUpdated) {
        try {
            String savedPath = storeItemPhoto(photoFile);
            database.updateItemPhoto(item.id, savedPath);
            item.photoPath = savedPath;
            if (onUpdated != null) {
                onUpdated.run();
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(frame,
                    "Could not read or store the selected photo: " + ex.getMessage(),
                    "Photo Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(frame,
                    "Could not save the photo link to the database: " + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void attachFinderPhotoToItem(Item item, Runnable onUpdated) {
        if (!ensureCanEditPhotos(item)) {
            return;
        }
        String role = "FOUND".equals(item.status) ? "Found" : "Lost";
        File chosen = chooseImageFile(frame, "Select Photo of the Person Who " + role + " It");
        if (chosen == null) {
            return;
        }
        saveFinderPhotoFile(item, chosen, onUpdated);
    }

    private void takeFinderPhotoForItem(Item item, Runnable onUpdated) {
        if (!ensureCanEditPhotos(item)) {
            return;
        }
        String role = "FOUND".equals(item.status) ? "Found" : "Lost";
        File captured = capturePhotoFromCamera("Take Photo of the Person Who " + role + " It — #" + item.id);
        if (captured == null) {
            return;
        }
        saveFinderPhotoFile(item, captured, onUpdated);
    }

    private void saveFinderPhotoFile(Item item, File photoFile, Runnable onUpdated) {
        try {
            String savedPath = storeFinderPhoto(photoFile);
            database.updateFinderPhoto(item.id, savedPath);
            item.finderPhotoPath = savedPath;
            if (onUpdated != null) {
                onUpdated.run();
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(frame,
                    "Could not read or store the selected person photo: " + ex.getMessage(),
                    "Photo Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(frame,
                    "Could not save the person photo link to the database: " + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private File capturePhotoFromCamera(String dialogTitle) {
        String osName = System.getProperty("os.name", "").toLowerCase(Locale.ENGLISH);
        if (!osName.contains("win")) {
            JOptionPane.showMessageDialog(frame,
                    "Direct camera capture currently supports Windows cameras. Please use 'Upload Photo' instead.",
                    "Camera Unsupported", JOptionPane.INFORMATION_MESSAGE);
            return null;
        }
        CameraCaptureDialog dialog = new CameraCaptureDialog(frame, dialogTitle);
        dialog.setVisible(true);
        return dialog.getCapturedFile();
    }

    private static final class CameraDevice {
        final String id;
        final String name;

        CameraDevice(String id, String name) {
            this.id = id;
            this.name = name;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    private static final class CameraPreviewCanvas extends JPanel {
        private volatile BufferedImage frameImage;
        private volatile String statusMessage = "Starting camera preview...";
        private volatile boolean capturedMode = false;
        private volatile boolean mirrored = false;

        CameraPreviewCanvas() {
            setBackground(new Color(22, 29, 38));
            setPreferredSize(new Dimension(620, 390));
        }

        void setFrameImage(BufferedImage img) {
            this.frameImage = img;
            this.statusMessage = null;
            repaint();
        }

        void setStatusMessage(String message) {
            this.frameImage = null;
            this.statusMessage = message;
            repaint();
        }

        void setCapturedMode(boolean captured) {
            this.capturedMode = captured;
            repaint();
        }

        void setMirrored(boolean mirrored) {
            this.mirrored = mirrored;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            try {
                g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int panelW = getWidth();
                int panelH = getHeight();
                BufferedImage img = frameImage;

                if (img != null && img.getWidth() > 0 && img.getHeight() > 0) {
                    double scale = Math.min((double) (panelW - 16) / img.getWidth(),
                            (double) (panelH - 16) / img.getHeight());
                    int drawW = Math.max(1, (int) Math.round(img.getWidth() * scale));
                    int drawH = Math.max(1, (int) Math.round(img.getHeight() * scale));
                    int drawX = (panelW - drawW) / 2;
                    int drawY = (panelH - drawH) / 2;

                    if (mirrored) {
                        g2.drawImage(img, drawX + drawW, drawY, -drawW, drawH, null);
                    } else {
                        g2.drawImage(img, drawX, drawY, drawW, drawH, null);
                    }

                    // Status pill badge
                    String badgeText = capturedMode ? "CAPTURED" : "LIVE";
                    Color badgeBg = capturedMode ? TEAL : new Color(196, 54, 54);
                    g2.setFont(new Font("SansSerif", Font.BOLD, 11));
                    int textW = g2.getFontMetrics().stringWidth(badgeText);
                    int pillW = textW + 18;
                    int pillH = 22;
                    g2.setColor(badgeBg);
                    g2.fillRoundRect(drawX + 10, drawY + 10, pillW, pillH, 10, 10);
                    g2.setColor(Color.WHITE);
                    g2.drawString(badgeText, drawX + 19, drawY + 25);
                } else {
                    String msg = statusMessage != null ? statusMessage : "Starting camera...";
                    g2.setColor(new Color(210, 220, 230));
                    g2.setFont(new Font("SansSerif", Font.PLAIN, 14));
                    String[] lines = msg.split("\n");
                    int lineHeight = g2.getFontMetrics().getHeight() + 4;
                    int startY = (panelH - (lines.length * lineHeight)) / 2 + g2.getFontMetrics().getAscent();
                    for (int i = 0; i < lines.length; i++) {
                        int lineW = g2.getFontMetrics().stringWidth(lines[i]);
                        g2.drawString(lines[i], Math.max(16, (panelW - lineW) / 2), startY + (i * lineHeight));
                    }
                }
            } finally {
                g2.dispose();
            }
        }
    }

    private final class CameraCaptureDialog extends JDialog {
        private static final String CAMERA_WORKER_SCRIPT =
                "param(\n"
                + "    [string]$StopFile,\n"
                + "    [string]$DeviceId = ''\n"
                + ")\n"
                + "$ErrorActionPreference = 'Stop'\n"
                + "Add-Type -AssemblyName System.Runtime.WindowsRuntime\n"
                + "$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {\n"
                + "    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'\n"
                + "})[0]\n"
                + "$asTaskAction = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {\n"
                + "    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction'\n"
                + "})[0]\n"
                + "function AwaitOp($op, $resultType) {\n"
                + "    $asTaskGeneric.MakeGenericMethod($resultType).Invoke($null, @($op)).GetAwaiter().GetResult()\n"
                + "}\n"
                + "function AwaitAction($op) {\n"
                + "    $asTaskAction.Invoke($null, @($op)).GetAwaiter().GetResult()\n"
                + "}\n"
                + "$null = [Windows.Devices.Enumeration.DeviceInformation, Windows.Devices.Enumeration, ContentType=WindowsRuntime]\n"
                + "$null = [Windows.Devices.Enumeration.DeviceClass, Windows.Devices.Enumeration, ContentType=WindowsRuntime]\n"
                + "$null = [Windows.Media.Capture.MediaCapture, Windows.Media.Capture, ContentType=WindowsRuntime]\n"
                + "$null = [Windows.Media.Capture.MediaCaptureInitializationSettings, Windows.Media.Capture, ContentType=WindowsRuntime]\n"
                + "$null = [Windows.Media.Capture.StreamingCaptureMode, Windows.Media.Capture, ContentType=WindowsRuntime]\n"
                + "$null = [Windows.Media.Capture.MediaCaptureMemoryPreference, Windows.Media.Capture, ContentType=WindowsRuntime]\n"
                + "$null = [Windows.Media.MediaProperties.ImageEncodingProperties, Windows.Media.MediaProperties, ContentType=WindowsRuntime]\n"
                + "$null = [Windows.Storage.Streams.InMemoryRandomAccessStream, Windows.Storage.Streams, ContentType=WindowsRuntime]\n"
                + "$null = [Windows.Storage.Streams.DataReader, Windows.Storage.Streams, ContentType=WindowsRuntime]\n"
                + "$devs = AwaitOp ([Windows.Devices.Enumeration.DeviceInformation]::FindAllAsync([Windows.Devices.Enumeration.DeviceClass]::VideoCapture)) ([Windows.Devices.Enumeration.DeviceInformationCollection])\n"
                + "foreach ($d in $devs) {\n"
                + "    if ($d.IsEnabled) {\n"
                + "        [Console]::Out.WriteLine('CAMERA:' + $d.Id + \"`t\" + $d.Name)\n"
                + "    }\n"
                + "}\n"
                + "[Console]::Out.WriteLine('CAMERAS_DONE')\n"
                + "[Console]::Out.Flush()\n"
                + "if ($devs.Count -eq 0) {\n"
                + "    [Console]::Out.WriteLine('ERROR:No camera device was detected on this computer.')\n"
                + "    [Console]::Out.Flush()\n"
                + "    exit 1\n"
                + "}\n"
                + "$targetId = $DeviceId\n"
                + "if ([string]::IsNullOrWhiteSpace($targetId)) {\n"
                + "    foreach ($d in $devs) {\n"
                + "        if ($d.IsEnabled) { $targetId = $d.Id; break }\n"
                + "    }\n"
                + "}\n"
                + "$settings = New-Object Windows.Media.Capture.MediaCaptureInitializationSettings\n"
                + "$settings.StreamingCaptureMode = [Windows.Media.Capture.StreamingCaptureMode]::Video\n"
                + "$settings.MemoryPreference = [Windows.Media.Capture.MediaCaptureMemoryPreference]::Cpu\n"
                + "if (-not [string]::IsNullOrWhiteSpace($targetId)) {\n"
                + "    $settings.VideoDeviceId = $targetId\n"
                + "}\n"
                + "$capture = New-Object Windows.Media.Capture.MediaCapture\n"
                + "try {\n"
                + "    AwaitAction ($capture.InitializeAsync($settings))\n"
                + "    [Console]::Out.WriteLine('READY')\n"
                + "    [Console]::Out.Flush()\n"
                + "    $encoding = [Windows.Media.MediaProperties.ImageEncodingProperties]::CreateJpeg()\n"
                + "    while (-not (Test-Path -LiteralPath $StopFile)) {\n"
                + "        $stream = New-Object Windows.Storage.Streams.InMemoryRandomAccessStream\n"
                + "        try {\n"
                + "            AwaitAction ($capture.CapturePhotoToStreamAsync($encoding, $stream))\n"
                + "            $size = [uint32]$stream.Size\n"
                + "            if ($size -gt 0) {\n"
                + "                $reader = New-Object Windows.Storage.Streams.DataReader($stream.GetInputStreamAt(0))\n"
                + "                try {\n"
                + "                    $loaded = AwaitOp ($reader.LoadAsync($size)) ([uint32])\n"
                + "                    $bytes = New-Object byte[] $loaded\n"
                + "                    $reader.ReadBytes($bytes)\n"
                + "                    $b64 = [Convert]::ToBase64String($bytes)\n"
                + "                    [Console]::Out.WriteLine('FRAME:' + $b64)\n"
                + "                    [Console]::Out.Flush()\n"
                + "                } finally {\n"
                + "                    $reader.Dispose()\n"
                + "                }\n"
                + "            }\n"
                + "        } finally {\n"
                + "            $stream.Dispose()\n"
                + "        }\n"
                + "        Start-Sleep -Milliseconds 35\n"
                + "    }\n"
                + "} catch {\n"
                + "    $msg = $_.Exception.Message\n"
                + "    if ($_.Exception.InnerException) {\n"
                + "        $msg = $_.Exception.InnerException.Message\n"
                + "    }\n"
                + "    $msg = ($msg -replace '[\\r\\n]+', ' ').Trim()\n"
                + "    [Console]::Out.WriteLine('ERROR:' + $msg)\n"
                + "    [Console]::Out.Flush()\n"
                + "    exit 1\n"
                + "} finally {\n"
                + "    if ($capture) {\n"
                + "        $capture.Dispose()\n"
                + "    }\n"
                + "}\n";

        private final CameraPreviewCanvas previewCanvas = new CameraPreviewCanvas();
        private final JComboBox<CameraDevice> cameraSelector = new JComboBox<>();
        private final JLabel statusLabel = new JLabel("Connecting to camera...");
        private final JCheckBox mirrorCheck = new JCheckBox("Mirror");
        private final JButton retryButton = secondaryButton("Retry Camera");
        private final JButton captureButton = primaryButton("Capture Photo");
        private final JButton retakeButton = secondaryButton("Retake");
        private final JButton usePhotoButton = primaryButton("Use Photo");
        private final JButton cancelButton = secondaryButton("Cancel");

        private volatile Process workerProcess;
        private volatile Path scriptFile;
        private volatile Path stopFile;
        private volatile BufferedImage latestLiveFrame;
        private volatile BufferedImage frozenFrame;
        private volatile boolean closed = false;
        private boolean updatingCameraCombo = false;
        private int sessionGeneration = 0;
        private File capturedFile;

        CameraCaptureDialog(JFrame owner, String dialogTitle) {
            super(owner, dialogTitle, true);
            setLayout(new BorderLayout(0, 0));
            getContentPane().setBackground(Color.WHITE);

            // Top bar
            JPanel topBar = new JPanel(new BorderLayout(12, 4));
            topBar.setBackground(Color.WHITE);
            topBar.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_LIGHT),
                    BorderFactory.createEmptyBorder(12, 16, 12, 16)));

            JPanel titleCol = new JPanel();
            titleCol.setOpaque(false);
            titleCol.setLayout(new BoxLayout(titleCol, BoxLayout.Y_AXIS));
            JLabel titleLbl = new JLabel(dialogTitle);
            titleLbl.setFont(new Font("SansSerif", Font.BOLD, 15));
            titleLbl.setForeground(NAVY);
            statusLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
            statusLabel.setForeground(new Color(95, 108, 120));
            titleCol.add(titleLbl);
            titleCol.add(Box.createVerticalStrut(3));
            titleCol.add(statusLabel);
            topBar.add(titleCol, BorderLayout.CENTER);

            JPanel camPickerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
            camPickerPanel.setOpaque(false);
            JLabel camLbl = new JLabel("Camera:");
            camLbl.setFont(new Font("SansSerif", Font.BOLD, 12));
            camLbl.setForeground(TEXT);
            cameraSelector.setFont(new Font("SansSerif", Font.PLAIN, 12));
            cameraSelector.setPreferredSize(new Dimension(210, 30));
            cameraSelector.addActionListener(e -> {
                if (!updatingCameraCombo) {
                    CameraDevice dev = (CameraDevice) cameraSelector.getSelectedItem();
                    if (dev != null) {
                        startCameraSession(dev.id);
                    }
                }
            });
            camPickerPanel.add(camLbl);
            camPickerPanel.add(cameraSelector);
            topBar.add(camPickerPanel, BorderLayout.EAST);
            add(topBar, BorderLayout.NORTH);

            // Center preview
            JPanel previewWrap = new JPanel(new BorderLayout());
            previewWrap.setBackground(new Color(22, 29, 38));
            previewWrap.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
            previewWrap.add(previewCanvas, BorderLayout.CENTER);
            add(previewWrap, BorderLayout.CENTER);

            // Bottom control bar
            JPanel bottomBar = new JPanel(new BorderLayout(10, 0));
            bottomBar.setBackground(Color.WHITE);
            bottomBar.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(1, 0, 0, 0, BORDER_LIGHT),
                    BorderFactory.createEmptyBorder(10, 16, 10, 16)));

            JPanel leftControls = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
            leftControls.setOpaque(false);
            mirrorCheck.setOpaque(false);
            mirrorCheck.setFocusPainted(false);
            mirrorCheck.setFont(new Font("SansSerif", Font.PLAIN, 12));
            mirrorCheck.setForeground(TEXT);
            mirrorCheck.addActionListener(e -> previewCanvas.setMirrored(mirrorCheck.isSelected()));
            retryButton.addActionListener(e -> {
                CameraDevice dev = (CameraDevice) cameraSelector.getSelectedItem();
                startCameraSession(dev != null ? dev.id : "");
            });
            leftControls.add(mirrorCheck);
            leftControls.add(retryButton);

            JPanel rightControls = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
            rightControls.setOpaque(false);

            captureButton.setEnabled(false);
            captureButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            captureButton.addActionListener(e -> freezeCurrentFrame());

            retakeButton.setVisible(false);
            retakeButton.addActionListener(e -> resumeLivePreview());

            usePhotoButton.setVisible(false);
            usePhotoButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            usePhotoButton.addActionListener(e -> confirmCapturedPhoto());

            cancelButton.addActionListener(e -> closeDialog());

            rightControls.add(retakeButton);
            rightControls.add(usePhotoButton);
            rightControls.add(captureButton);
            rightControls.add(cancelButton);

            bottomBar.add(leftControls, BorderLayout.WEST);
            bottomBar.add(rightControls, BorderLayout.EAST);
            add(bottomBar, BorderLayout.SOUTH);

            setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
            addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e) {
                    closeDialog();
                }
            });

            pack();
            setSize(700, 560);
            setMinimumSize(new Dimension(560, 440));
            setLocationRelativeTo(owner);

            startCameraSession("");
        }

        File getCapturedFile() {
            return capturedFile;
        }

        private void freezeCurrentFrame() {
            BufferedImage frameImg = latestLiveFrame;
            if (frameImg == null) {
                return;
            }
            frozenFrame = frameImg;
            previewCanvas.setFrameImage(frameImg);
            previewCanvas.setCapturedMode(true);
            captureButton.setVisible(false);
            retakeButton.setVisible(true);
            usePhotoButton.setVisible(true);
            statusLabel.setText("Photo captured — click 'Use Photo' to keep it or 'Retake' to try again.");
        }

        private void resumeLivePreview() {
            frozenFrame = null;
            previewCanvas.setCapturedMode(false);
            captureButton.setVisible(true);
            captureButton.setEnabled(latestLiveFrame != null);
            retakeButton.setVisible(false);
            usePhotoButton.setVisible(false);
            if (latestLiveFrame != null) {
                previewCanvas.setFrameImage(latestLiveFrame);
            }
            statusLabel.setText("Live camera preview — click 'Capture Photo' when ready.");
        }

        private void confirmCapturedPhoto() {
            BufferedImage source = frozenFrame;
            if (source == null) {
                return;
            }
            try {
                BufferedImage rgb = new BufferedImage(source.getWidth(), source.getHeight(), BufferedImage.TYPE_INT_RGB);
                Graphics2D g2 = rgb.createGraphics();
                try {
                    if (mirrorCheck.isSelected()) {
                        g2.drawImage(source, source.getWidth(), 0, -source.getWidth(), source.getHeight(), null);
                    } else {
                        g2.drawImage(source, 0, 0, null);
                    }
                } finally {
                    g2.dispose();
                }
                File outFile = File.createTempFile("findagain_cam_", ".jpg");
                outFile.deleteOnExit();
                if (!ImageIO.write(rgb, "jpg", outFile)) {
                    throw new IOException("JPEG encoder unavailable.");
                }
                capturedFile = outFile;
                closeDialog();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this,
                        "Could not save the captured photo: " + ex.getMessage(),
                        "Save Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        private void startCameraSession(String requestedDeviceId) {
            stopCurrentWorker();
            final int gen = ++sessionGeneration;
            frozenFrame = null;
            latestLiveFrame = null;
            previewCanvas.setCapturedMode(false);
            previewCanvas.setStatusMessage("Starting camera preview...");
            captureButton.setVisible(true);
            captureButton.setEnabled(false);
            retakeButton.setVisible(false);
            usePhotoButton.setVisible(false);
            statusLabel.setText("Connecting to camera...");

            Thread workerThread = new Thread(() -> runCameraWorker(gen, requestedDeviceId), "CameraWorker-" + gen);
            workerThread.setDaemon(true);
            workerThread.start();
        }

        private void runCameraWorker(int gen, String requestedDeviceId) {
            Path localScript = null;
            Path localStop = null;
            Process proc = null;
            try {
                localScript = Files.createTempFile("findagain_cam_worker_", ".ps1");
                Files.write(localScript, CAMERA_WORKER_SCRIPT.getBytes(StandardCharsets.UTF_8));
                localStop = Paths.get(localScript.toString() + ".stop");
                Files.deleteIfExists(localStop);

                scriptFile = localScript;
                stopFile = localStop;

                List<String> cmd = new ArrayList<>();
                cmd.add("powershell.exe");
                cmd.add("-NoProfile");
                cmd.add("-NonInteractive");
                cmd.add("-ExecutionPolicy");
                cmd.add("Bypass");
                cmd.add("-File");
                cmd.add(localScript.toAbsolutePath().toString());
                cmd.add("-StopFile");
                cmd.add(localStop.toAbsolutePath().toString());
                if (requestedDeviceId != null && !requestedDeviceId.isEmpty()) {
                    cmd.add("-DeviceId");
                    cmd.add(requestedDeviceId);
                }

                ProcessBuilder pb = new ProcessBuilder(cmd);
                pb.redirectErrorStream(false);
                proc = pb.start();
                workerProcess = proc;

                // Drain stderr asynchronously so buffers never block
                final InputStream errStream = proc.getErrorStream();
                Thread errDrainer = new Thread(() -> {
                    try (BufferedReader er = new BufferedReader(new InputStreamReader(errStream, StandardCharsets.UTF_8))) {
                        while (er.readLine() != null) {
                            // discard noisy PowerShell stderr
                        }
                    } catch (IOException ignored) {
                    }
                }, "CameraStderr-" + gen);
                errDrainer.setDaemon(true);
                errDrainer.start();

                List<CameraDevice> discoveredDevices = new ArrayList<>();
                boolean receivedFrame = false;

                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(proc.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while (!closed && gen == sessionGeneration && (line = reader.readLine()) != null) {
                        if (line.startsWith("CAMERA:")) {
                            String payload = line.substring("CAMERA:".length());
                            int tab = payload.indexOf('\t');
                            if (tab > 0) {
                                discoveredDevices.add(new CameraDevice(
                                        payload.substring(0, tab),
                                        payload.substring(tab + 1)));
                            }
                        } else if ("CAMERAS_DONE".equals(line)) {
                            final List<CameraDevice> listCopy = new ArrayList<>(discoveredDevices);
                            SwingUtilities.invokeLater(() -> populateCameraDropdown(gen, listCopy, requestedDeviceId));
                        } else if ("READY".equals(line)) {
                            SwingUtilities.invokeLater(() -> {
                                if (!closed && gen == sessionGeneration) {
                                    statusLabel.setText("Camera ready — loading live preview...");
                                }
                            });
                        } else if (line.startsWith("FRAME:")) {
                            String b64 = line.substring("FRAME:".length());
                            try {
                                byte[] bytes = Base64.getDecoder().decode(b64);
                                BufferedImage decoded = ImageIO.read(new ByteArrayInputStream(bytes));
                                if (decoded != null) {
                                    latestLiveFrame = decoded;
                                    final boolean firstFrame = !receivedFrame;
                                    receivedFrame = true;
                                    SwingUtilities.invokeLater(() -> {
                                        if (!closed && gen == sessionGeneration && frozenFrame == null) {
                                            previewCanvas.setFrameImage(decoded);
                                            if (firstFrame) {
                                                captureButton.setEnabled(true);
                                                statusLabel.setText("Live camera preview — click 'Capture Photo' when ready.");
                                            }
                                        }
                                    });
                                }
                            } catch (IllegalArgumentException | IOException ignored) {
                            }
                        } else if (line.startsWith("ERROR:")) {
                            final String rawErr = line.substring("ERROR:".length()).trim();
                            SwingUtilities.invokeLater(() -> showCameraError(gen, rawErr));
                        }
                    }
                }
            } catch (IOException ex) {
                final String errMsg = ex.getMessage() != null ? ex.getMessage() : "Could not start camera helper.";
                SwingUtilities.invokeLater(() -> showCameraError(gen, errMsg));
            } finally {
                if (proc != null) {
                    proc.destroyForcibly();
                }
                deleteQuietly(localStop);
                deleteQuietly(localScript);
            }
        }

        private void populateCameraDropdown(int gen, List<CameraDevice> devices, String requestedDeviceId) {
            if (closed || gen != sessionGeneration) {
                return;
            }
            updatingCameraCombo = true;
            try {
                cameraSelector.removeAllItems();
                CameraDevice toSelect = null;
                for (CameraDevice dev : devices) {
                    cameraSelector.addItem(dev);
                    if (requestedDeviceId != null && requestedDeviceId.equals(dev.id)) {
                        toSelect = dev;
                    }
                }
                if (toSelect != null) {
                    cameraSelector.setSelectedItem(toSelect);
                } else if (!devices.isEmpty()) {
                    cameraSelector.setSelectedIndex(0);
                }
                cameraSelector.setEnabled(devices.size() > 1);
            } finally {
                updatingCameraCombo = false;
            }
        }

        private void showCameraError(int gen, String rawError) {
            if (closed || gen != sessionGeneration) {
                return;
            }
            String lower = rawError != null ? rawError.toLowerCase(Locale.ENGLISH) : "";
            String friendly;
            if (lower.contains("access is denied") || lower.contains("unauthorized")) {
                friendly = "Camera access was denied by Windows.\n"
                        + "Enable Settings > Privacy & security > Camera > 'Let desktop apps access your camera',\n"
                        + "then click 'Retry Camera' (or close and use 'Upload Photo').";
            } else if (lower.contains("in use") || lower.contains("busy")) {
                friendly = "Camera is currently in use by another app.\n"
                        + "Close other camera apps and click 'Retry Camera', or pick another camera above.";
            } else {
                friendly = "Could not open camera:\n" + rawError
                        + "\nTry selecting another camera above, clicking 'Retry Camera', or using 'Upload Photo'.";
            }
            previewCanvas.setStatusMessage(friendly);
            captureButton.setEnabled(false);
            statusLabel.setText("Camera unavailable — check permissions or switch camera.");
        }

        private void stopCurrentWorker() {
            Path currentStop = stopFile;
            Process currentProc = workerProcess;
            if (currentStop != null) {
                try {
                    Files.write(currentStop, new byte[]{1});
                } catch (IOException ignored) {
                }
            }
            if (currentProc != null) {
                try {
                    currentProc.waitFor(450, TimeUnit.MILLISECONDS);
                } catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                }
                if (currentProc.isAlive()) {
                    currentProc.destroyForcibly();
                }
            }
            deleteQuietly(currentStop);
            deleteQuietly(scriptFile);
        }

        private void closeDialog() {
            closed = true;
            sessionGeneration++;
            stopCurrentWorker();
            dispose();
        }

        private void deleteQuietly(Path p) {
            if (p != null) {
                try {
                    Files.deleteIfExists(p);
                } catch (IOException ignored) {
                }
            }
        }
    }

    private void removePhotoFromItem(Item item, Runnable onUpdated) {
        if (!ensureCanEditPhotos(item)) {
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(frame,
                "Remove the attached photo from " + item.status + " report #" + item.id + " (" + item.name + ")?",
                "Remove Photo", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }
        try {
            database.updateItemPhoto(item.id, "");
            item.photoPath = "";
            if (onUpdated != null) {
                onUpdated.run();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(frame,
                    "Could not remove the photo from the database: " + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void openFullPhotoDialog(Item item) {
        String headerHtml = "<html><b>" + escapeHtml(item.status) + " #" + item.id + " — " + escapeHtml(item.name)
                + "</b> &nbsp;|&nbsp; " + escapeHtml(item.location) + " (" + escapeHtml(item.dateTime) + ")</html>";
        openFullImageDialog(
                item.status + " Item Photo — #" + item.id + " " + item.name,
                headerHtml,
                item.photoPath,
                "The photo for report #" + item.id + " could not be loaded.");
    }

    private void openFullFinderPhotoDialog(Item item) {
        String roleTitle = "FOUND".equals(item.status) ? "Person Who Found It" : "Person Who Lost It";
        String statusWord = "FOUND".equals(item.status) ? "Found" : "Lost";
        String headerHtml = "<html><b>" + roleTitle + " — " + escapeHtml(item.reporter)
                + " (" + escapeHtml(item.registrationId) + ")</b> &nbsp;|&nbsp; " + statusWord + " #" + item.id
                + " " + escapeHtml(item.name) + " &nbsp;|&nbsp; Contact: " + escapeHtml(item.contact) + "</html>";
        openFullImageDialog(
                roleTitle + " — " + item.reporter + " (" + statusWord + " #" + item.id + ")",
                headerHtml,
                item.finderPhotoPath,
                "The person photo for report #" + item.id + " could not be loaded.");
    }

    private void openFullImageDialog(String dialogTitle, String headerHtml, String photoPath, String unavailableMsg) {
        ImageIcon fullIcon = loadScaledPhoto(photoPath, 820, 560);
        if (fullIcon == null) {
            JOptionPane.showMessageDialog(frame,
                    unavailableMsg,
                    "Photo Unavailable", JOptionPane.WARNING_MESSAGE);
            return;
        }
        JDialog dialog = new JDialog(frame, dialogTitle, true);
        dialog.setLayout(new BorderLayout(0, 10));
        dialog.getContentPane().setBackground(Color.WHITE);

        JLabel header = new JLabel(headerHtml);
        header.setFont(new Font("SansSerif", Font.PLAIN, 13));
        header.setForeground(NAVY);
        header.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_LIGHT),
                BorderFactory.createEmptyBorder(12, 16, 12, 16)));
        dialog.add(header, BorderLayout.NORTH);

        JLabel imageLabel = new JLabel(fullIcon, SwingConstants.CENTER);
        imageLabel.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));
        dialog.add(new JScrollPane(imageLabel), BorderLayout.CENTER);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 8));
        footer.setBackground(Color.WHITE);
        JButton closeBtn = primaryButton("Close");
        closeBtn.addActionListener(e -> dialog.dispose());
        footer.add(closeBtn);
        dialog.add(footer, BorderLayout.SOUTH);

        dialog.pack();
        int maxW = Math.min(900, Math.max(520, dialog.getWidth()));
        int maxH = Math.min(700, Math.max(420, dialog.getHeight()));
        dialog.setSize(maxW, maxH);
        dialog.setLocationRelativeTo(frame);
        dialog.setVisible(true);
    }

    private static final class ScrollablePanel extends JPanel implements Scrollable {
        @Override
        public Dimension getPreferredScrollableViewportSize() {
            return getPreferredSize();
        }

        @Override
        public int getScrollableUnitIncrement(Rectangle visibleRect, int orientation, int direction) {
            return 18;
        }

        @Override
        public int getScrollableBlockIncrement(Rectangle visibleRect, int orientation, int direction) {
            return 80;
        }

        @Override
        public boolean getScrollableTracksViewportWidth() {
            return true;
        }

        @Override
        public boolean getScrollableTracksViewportHeight() {
            return false;
        }
    }

    private static List<Item> findMatches(Item selected) {
        List<Item> matches = new ArrayList<>();
        for (Item candidate : items) {
            if (candidate.id != selected.id
                    && !candidate.status.equals(selected.status)
                    && getMatchScore(selected, candidate) >= 2) {
                matches.add(candidate);
            }
        }
        return matches;
    }

    private static int getMatchScore(Item first, Item second) {
        int score = 0;
        if (first.category.equalsIgnoreCase(second.category)) {
            score++;
        }
        if (hasCommonWord(first.appearance, second.appearance)) {
            score++;
        }
        if (first.name.equalsIgnoreCase(second.name)) {
            score += 2;
        }
        if (first.location.equalsIgnoreCase(second.location)) {
            score++;
        }
        return score;
    }

    private static boolean hasCommonWord(String first, String second) {
        String[] firstWords = first.toLowerCase().split("\\W+");
        String secondText = " " + second.toLowerCase() + " ";
        for (String word : firstWords) {
            if (word.length() > 2 && secondText.contains(" " + word + " ")) {
                return true;
            }
        }
        return false;
    }

    private static String escapeHtml(String text) {
        if (text == null) {
            return "";
        }
        return text.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;");
    }

    static final class PasswordHasher {
        private static final String ALGORITHM = "PBKDF2WithHmacSHA256";
        private static final int ITERATIONS = 65536;
        private static final int KEY_LENGTH = 256;
        private static final int SALT_BYTES = 16;
        private static final SecureRandom RANDOM = new SecureRandom();

        static String generateSalt() {
            byte[] salt = new byte[SALT_BYTES];
            RANDOM.nextBytes(salt);
            return Base64.getEncoder().encodeToString(salt);
        }

        static String hashSecret(String secret, String base64Salt) {
            try {
                byte[] salt = Base64.getDecoder().decode(base64Salt);
                PBEKeySpec spec = new PBEKeySpec(secret.toCharArray(), salt, ITERATIONS, KEY_LENGTH);
                try {
                    SecretKeyFactory factory = SecretKeyFactory.getInstance(ALGORITHM);
                    byte[] hash = factory.generateSecret(spec).getEncoded();
                    return Base64.getEncoder().encodeToString(hash);
                } finally {
                    spec.clearPassword();
                }
            } catch (NoSuchAlgorithmException | InvalidKeySpecException ex) {
                throw new IllegalStateException("Password hashing algorithm unavailable", ex);
            }
        }

        static boolean verifySecret(String candidateSecret, String base64Salt, String expectedBase64Hash) {
            String candidateHash = hashSecret(candidateSecret, base64Salt);
            byte[] a = candidateHash.getBytes(java.nio.charset.StandardCharsets.UTF_8);
            byte[] b = expectedBase64Hash.getBytes(java.nio.charset.StandardCharsets.UTF_8);
            return MessageDigest.isEqual(a, b);
        }
    }

    static final class LoginRateLimiter {
        private final int maxAttempts;
        private final long lockoutDurationMs;
        private final Map<String, AttemptRecord> attemptsByReg = new HashMap<>();

        LoginRateLimiter(int maxAttempts, long lockoutDurationMs) {
            this.maxAttempts = maxAttempts;
            this.lockoutDurationMs = lockoutDurationMs;
        }

        synchronized long getRemainingLockoutMs(String regNumber) {
            AttemptRecord rec = attemptsByReg.get(regNumber);
            if (rec == null || rec.lockedUntilMs <= 0) {
                return 0L;
            }
            long now = System.currentTimeMillis();
            if (now >= rec.lockedUntilMs) {
                attemptsByReg.remove(regNumber);
                return 0L;
            }
            return rec.lockedUntilMs - now;
        }

        synchronized void recordFailure(String regNumber) {
            long now = System.currentTimeMillis();
            AttemptRecord rec = attemptsByReg.get(regNumber);
            if (rec == null || (rec.lockedUntilMs > 0 && now >= rec.lockedUntilMs)) {
                rec = new AttemptRecord();
                attemptsByReg.put(regNumber, rec);
            }
            rec.failedCount++;
            if (rec.failedCount >= maxAttempts) {
                rec.lockedUntilMs = now + lockoutDurationMs;
            }
        }

        synchronized void reset(String regNumber) {
            attemptsByReg.remove(regNumber);
        }

        private static final class AttemptRecord {
            int failedCount;
            long lockedUntilMs;
        }
    }

    static final class AuthenticatedUser {
        final String registrationNumber;
        final String fullName;
        final String contact;

        AuthenticatedUser(String registrationNumber, String fullName, String contact) {
            this.registrationNumber = registrationNumber;
            this.fullName = fullName;
            this.contact = contact;
        }
    }

    private static final class UserSession {
        final String token;
        final AuthenticatedUser user;
        final long createdAtMs;

        UserSession(String token, AuthenticatedUser user, long createdAtMs) {
            this.token = token;
            this.user = user;
            this.createdAtMs = createdAtMs;
        }
    }

    static class ItemDatabase {
        private static final String DATABASE_URL = "jdbc:sqlite:data/srm-ap-lost-found.db";
        private static final String DUMMY_SALT = PasswordHasher.generateSalt();
        private static final String DUMMY_HASH = PasswordHasher.hashSecret("00000000", DUMMY_SALT);

        ItemDatabase() throws SQLException {
            java.io.File dataDirectory = new java.io.File("data");
            if (!dataDirectory.exists() && !dataDirectory.mkdirs()) {
                throw new SQLException("Could not create the data directory.");
            }

            try (Connection connection = DriverManager.getConnection(DATABASE_URL);
                 Statement statement = connection.createStatement()) {
                statement.executeUpdate(
                        "CREATE TABLE IF NOT EXISTS item_reports ("
                        + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + "status TEXT NOT NULL, "
                        + "item_name TEXT NOT NULL, "
                        + "category TEXT NOT NULL, "
                        + "location TEXT NOT NULL, "
                        + "date_time TEXT NOT NULL, "
                        + "appearance TEXT NOT NULL, "
                        + "condition TEXT NOT NULL, "
                        + "registration_id TEXT NOT NULL, "
                        + "reporter TEXT NOT NULL, "
                        + "contact TEXT NOT NULL, "
                        + "photo_path TEXT NOT NULL DEFAULT '', "
                        + "finder_photo_path TEXT NOT NULL DEFAULT ''"
                        + ")");

                ensurePhotoColumnsExist(connection);

                statement.executeUpdate(
                        "CREATE TABLE IF NOT EXISTS users ("
                        + "registration_number TEXT PRIMARY KEY, "
                        + "full_name TEXT NOT NULL, "
                        + "contact TEXT NOT NULL, "
                        + "dob_hash TEXT NOT NULL, "
                        + "password_hash TEXT NOT NULL, "
                        + "password_salt TEXT NOT NULL, "
                        + "created_at TEXT NOT NULL"
                        + ")");
            }
            seedExistingAndDefaultUsers();
        }

        private void seedExistingAndDefaultUsers() throws SQLException {
            List<String[]> existingReporters = new ArrayList<>();
            String query = "SELECT DISTINCT registration_id, reporter, contact FROM item_reports";
            try (Connection connection = DriverManager.getConnection(DATABASE_URL);
                 Statement statement = connection.createStatement();
                 ResultSet rs = statement.executeQuery(query)) {
                while (rs.next()) {
                    String regId = rs.getString("registration_id");
                    String reporter = rs.getString("reporter");
                    String contact = rs.getString("contact");
                    if (regId != null && REGISTRATION_PATTERN.matcher(regId.trim()).matches()) {
                        existingReporters.add(new String[]{regId.trim(), reporter, contact});
                    }
                }
            }
            for (String[] rep : existingReporters) {
                if (!userExists(rep[0])) {
                    registerUser(rep[0], rep[1], rep[2], "15082005");
                }
            }
            if (!userExists("AP12345678901")) {
                registerUser("AP12345678901", "SRM AP Student", "student@srmap.edu.in", "15082005");
            }
            if (!userExists("AP25110071048")) {
                registerUser("AP25110071048", "SRM AP Student", "student@srmap.edu.in", "28122006");
            }
        }

        boolean userExists(String registrationNumber) throws SQLException {
            String sql = "SELECT 1 FROM users WHERE registration_number = ?";
            try (Connection connection = DriverManager.getConnection(DATABASE_URL);
                 PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, registrationNumber);
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next();
                }
            }
        }

        void registerUser(String registrationNumber, String fullName, String contact, String dobCompact)
                throws SQLException {
            String regError = validateRegistrationNumber(registrationNumber);
            if (regError != null) {
                throw new SQLException(regError);
            }
            String normalizedDob = normalizeDobToCompact(dobCompact);
            if (normalizedDob == null) {
                throw new SQLException("Invalid Date of Birth format. Expected DDMMYYYY.");
            }
            String salt = PasswordHasher.generateSalt();
            String dobHash = PasswordHasher.hashSecret(normalizedDob, salt);
            String sql = "INSERT INTO users (registration_number, full_name, contact, dob_hash, password_hash, password_salt, created_at) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (Connection connection = DriverManager.getConnection(DATABASE_URL);
                 PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, registrationNumber.trim());
                ps.setString(2, fullName.trim());
                ps.setString(3, contact.trim());
                ps.setString(4, dobHash);
                ps.setString(5, dobHash);
                ps.setString(6, salt);
                ps.setString(7, LocalDate.now().toString());
                ps.executeUpdate();
            }
        }

        AuthenticatedUser authenticateUser(String registrationNumber, String password) throws SQLException {
            if (validateRegistrationNumber(registrationNumber) != null || password == null || password.isEmpty()) {
                return null;
            }
            String trimmedReg = registrationNumber.trim();
            String normalizedDobCandidate = normalizeDobToCompact(password);

            String sql = "SELECT registration_number, full_name, contact, password_hash, password_salt "
                    + "FROM users WHERE registration_number = ?";
            try (Connection connection = DriverManager.getConnection(DATABASE_URL);
                 PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, trimmedReg);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        if (normalizedDobCandidate != null) {
                            String[] existingInfo = findReporterInfo(connection, trimmedReg);
                            registerUser(trimmedReg, existingInfo[0], existingInfo[1], normalizedDobCandidate);
                            return new AuthenticatedUser(trimmedReg, existingInfo[0], existingInfo[1]);
                        }
                        PasswordHasher.verifySecret(password, DUMMY_SALT, DUMMY_HASH);
                        return null;
                    }
                    String fullName = rs.getString("full_name");
                    String contact = rs.getString("contact");
                    String storedHash = rs.getString("password_hash");
                    String storedSalt = rs.getString("password_salt");

                    boolean matched = PasswordHasher.verifySecret(password, storedSalt, storedHash);
                    if (!matched && normalizedDobCandidate != null) {
                        matched = PasswordHasher.verifySecret(normalizedDobCandidate, storedSalt, storedHash);
                        if (!matched) {
                            String newSalt = PasswordHasher.generateSalt();
                            String newHash = PasswordHasher.hashSecret(normalizedDobCandidate, newSalt);
                            try (PreparedStatement ups = connection.prepareStatement(
                                    "UPDATE users SET dob_hash = ?, password_hash = ?, password_salt = ? WHERE registration_number = ?")) {
                                ups.setString(1, newHash);
                                ups.setString(2, newHash);
                                ups.setString(3, newSalt);
                                ups.setString(4, trimmedReg);
                                ups.executeUpdate();
                            }
                            matched = true;
                        }
                    }
                    if (!matched) {
                        return null;
                    }
                    return new AuthenticatedUser(trimmedReg, fullName, contact);
                }
            }
        }

        private String[] findReporterInfo(Connection connection, String registrationNumber) throws SQLException {
            String query = "SELECT reporter, contact FROM item_reports WHERE registration_id = ? LIMIT 1";
            try (PreparedStatement ps = connection.prepareStatement(query)) {
                ps.setString(1, registrationNumber);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        String rep = rs.getString("reporter");
                        String con = rs.getString("contact");
                        return new String[]{
                            (rep != null && !rep.trim().isEmpty()) ? rep.trim() : "Student " + registrationNumber,
                            (con != null) ? con.trim() : ""
                        };
                    }
                }
            }
            return new String[]{"Student " + registrationNumber, ""};
        }

        boolean resetPasswordWithDob(String registrationNumber, String dobCompact, String newPassword)
                throws SQLException {
            if (validateRegistrationNumber(registrationNumber) != null) {
                return false;
            }
            String normalizedDob = normalizeDobToCompact(dobCompact);
            if (normalizedDob == null || newPassword == null || newPassword.isEmpty()) {
                return false;
            }
            String selectSql = "SELECT dob_hash, password_salt FROM users WHERE registration_number = ?";
            try (Connection connection = DriverManager.getConnection(DATABASE_URL);
                 PreparedStatement ps = connection.prepareStatement(selectSql)) {
                ps.setString(1, registrationNumber.trim());
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        PasswordHasher.verifySecret(normalizedDob, DUMMY_SALT, DUMMY_HASH);
                        return false;
                    }
                    String dobHash = rs.getString("dob_hash");
                    String salt = rs.getString("password_salt");
                    if (!PasswordHasher.verifySecret(normalizedDob, salt, dobHash)) {
                        return false;
                    }
                }
            }

            String newSalt = PasswordHasher.generateSalt();
            String newDobHash = PasswordHasher.hashSecret(normalizedDob, newSalt);
            String newPasswordHash = PasswordHasher.hashSecret(newPassword, newSalt);
            String updateSql = "UPDATE users SET dob_hash = ?, password_hash = ?, password_salt = ? WHERE registration_number = ?";
            try (Connection connection = DriverManager.getConnection(DATABASE_URL);
                 PreparedStatement updatePs = connection.prepareStatement(updateSql)) {
                updatePs.setString(1, newDobHash);
                updatePs.setString(2, newPasswordHash);
                updatePs.setString(3, newSalt);
                updatePs.setString(4, registrationNumber.trim());
                return updatePs.executeUpdate() == 1;
            }
        }

        private void ensurePhotoColumnsExist(Connection connection) throws SQLException {
            boolean hasPhotoColumn = false;
            boolean hasFinderPhotoColumn = false;
            try (Statement statement = connection.createStatement();
                 ResultSet rs = statement.executeQuery("PRAGMA table_info(item_reports)")) {
                while (rs.next()) {
                    String colName = rs.getString("name");
                    if ("photo_path".equalsIgnoreCase(colName)) {
                        hasPhotoColumn = true;
                    } else if ("finder_photo_path".equalsIgnoreCase(colName)) {
                        hasFinderPhotoColumn = true;
                    }
                }
            }
            if (!hasPhotoColumn) {
                try (Statement alter = connection.createStatement()) {
                    alter.executeUpdate("ALTER TABLE item_reports ADD COLUMN photo_path TEXT NOT NULL DEFAULT ''");
                }
            }
            if (!hasFinderPhotoColumn) {
                try (Statement alter = connection.createStatement()) {
                    alter.executeUpdate("ALTER TABLE item_reports ADD COLUMN finder_photo_path TEXT NOT NULL DEFAULT ''");
                }
            }
        }

        private List<Item> loadItems() throws SQLException {
            List<Item> loadedItems = new ArrayList<>();
            String sql = "SELECT id, status, item_name, category, location, date_time, "
                    + "appearance, condition, registration_id, reporter, contact, photo_path, finder_photo_path "
                    + "FROM item_reports ORDER BY id";
            try (Connection connection = DriverManager.getConnection(DATABASE_URL);
                 Statement statement = connection.createStatement();
                 ResultSet results = statement.executeQuery(sql)) {
                while (results.next()) {
                    loadedItems.add(new Item(
                            results.getInt("id"),
                            results.getString("status"),
                            results.getString("item_name"),
                            results.getString("category"),
                            results.getString("location"),
                            results.getString("date_time"),
                            results.getString("appearance"),
                            results.getString("condition"),
                            results.getString("registration_id"),
                            results.getString("reporter"),
                            results.getString("contact"),
                            results.getString("photo_path"),
                            results.getString("finder_photo_path")));
                }
            }
            return loadedItems;
        }

        private Item saveItem(Item item) throws SQLException {
            String insertSql = "INSERT INTO item_reports "
                    + "(status, item_name, category, location, date_time, appearance, "
                    + "condition, registration_id, reporter, contact, photo_path, finder_photo_path) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            try (Connection connection = DriverManager.getConnection(DATABASE_URL);
                 PreparedStatement insert = connection.prepareStatement(insertSql);
                 Statement idQuery = connection.createStatement()) {
                insert.setString(1, item.status);
                insert.setString(2, item.name);
                insert.setString(3, item.category);
                insert.setString(4, item.location);
                insert.setString(5, item.dateTime);
                insert.setString(6, item.appearance);
                insert.setString(7, item.condition);
                insert.setString(8, item.registrationId);
                insert.setString(9, item.reporter);
                insert.setString(10, item.contact);
                insert.setString(11, item.photoPath != null ? item.photoPath : "");
                insert.setString(12, item.finderPhotoPath != null ? item.finderPhotoPath : "");
                insert.executeUpdate();

                try (ResultSet result = idQuery.executeQuery("SELECT last_insert_rowid()")) {
                    if (!result.next()) {
                        throw new SQLException("The database did not return a report ID.");
                    }
                    return new Item(result.getInt(1), item.status, item.name, item.category,
                            item.location, item.dateTime, item.appearance, item.condition,
                            item.registrationId, item.reporter, item.contact, item.photoPath,
                            item.finderPhotoPath);
                }
            }
        }

        void updateItemPhoto(int itemId, String photoPath) throws SQLException {
            String sql = "UPDATE item_reports SET photo_path = ? WHERE id = ?";
            try (Connection connection = DriverManager.getConnection(DATABASE_URL);
                 PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, photoPath != null ? photoPath : "");
                ps.setInt(2, itemId);
                ps.executeUpdate();
            }
        }

        void updateFinderPhoto(int itemId, String finderPhotoPath) throws SQLException {
            String sql = "UPDATE item_reports SET finder_photo_path = ? WHERE id = ?";
            try (Connection connection = DriverManager.getConnection(DATABASE_URL);
                 PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, finderPhotoPath != null ? finderPhotoPath : "");
                ps.setInt(2, itemId);
                ps.executeUpdate();
            }
        }
    }

    private static class Item {
        private final int id;
        private final String status;
        private final String name;
        private final String category;
        private final String location;
        private final String dateTime;
        private final String appearance;
        private final String condition;
        private final String registrationId;
        private final String reporter;
        private final String contact;
        private String photoPath;
        private String finderPhotoPath;

        private Item(int id, String status, String name, String category,
                     String location, String dateTime, String appearance, String condition,
                     String registrationId, String reporter, String contact, String photoPath,
                     String finderPhotoPath) {
            this.id = id;
            this.status = status;
            this.name = name;
            this.category = category;
            this.location = location;
            this.dateTime = dateTime;
            this.appearance = appearance;
            this.condition = condition;
            this.registrationId = registrationId;
            this.reporter = reporter;
            this.contact = contact;
            this.photoPath = photoPath != null ? photoPath : "";
            this.finderPhotoPath = finderPhotoPath != null ? finderPhotoPath : "";
        }

        private boolean hasPhoto() {
            return photoPath != null && !photoPath.trim().isEmpty();
        }

        private boolean hasFinderPhoto() {
            return finderPhotoPath != null && !finderPhotoPath.trim().isEmpty();
        }

        @Override
        public String toString() {
            return "#" + id + "  " + status + " - " + name
                    + " (" + location + ", " + dateTime + ")";
        }
    }
}
